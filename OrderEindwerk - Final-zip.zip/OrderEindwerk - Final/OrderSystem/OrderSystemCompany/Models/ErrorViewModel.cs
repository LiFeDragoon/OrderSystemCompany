namespace OrderSystemCompany.Models
{
    // Model class representing the error view
    public class ErrorViewModel
    {
        // Property to hold the request ID associated with the error
        public string? RequestId { get; set; }

        // Property that indicates whether the request ID should be shown
        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
