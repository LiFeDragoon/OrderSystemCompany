﻿using System.ComponentModel.DataAnnotations;

namespace OrderSystemCompany.UI.Models
{
    // Model class representing the admin rules
    public class AdminRulesModels
    {
        // Email property for the admin user
        public string? Email { get; set; }

        // Flag indicating whether the email is confirmed for the admin user
        public bool? IsEmailConfirmed { get; set; }

        // Status message for the admin user
        public string? StatusMessage { get; set; }

        // InputModel class for capturing user input
        public class InputModel
        {
            // Required attribute specifies that the email field is mandatory
            [Required]

            // EmailAddress attribute validates that the input is in a valid email format
            [EmailAddress]

            // Email property for capturing user email input
            public string? Email { get; set; }
        }
    }
}
