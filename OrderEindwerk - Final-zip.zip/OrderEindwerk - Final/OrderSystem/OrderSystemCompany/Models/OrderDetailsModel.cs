﻿using OrderSystemCompany.Objects;

namespace OrderSystemCompany.UI.Models
{
    // Model class representing the order details
    public class OrderDetailsModel
    {
        // Property to hold the order object
        public Order order { get; set; }

        // Property to hold the stock product object
        public StockProduct stockProduct { get; set; }

        // Property to hold the order details object
        public OrderDetails orderDetails { get; set; }
    }
}
