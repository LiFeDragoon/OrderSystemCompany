﻿namespace OrderSystemCompany.UI.Models
{
    // Model class representing a user
    public class UserModels
    {
        // Property to hold the user ID
        public string Id { get; set; }

        // Property to hold the username
        public string? Username { get; set; }

        // Property to hold the user's address
        public string? Address { get; set; }

        // Property to hold the user's postal code
        public string? PostalCode { get; set; }

        // Property to hold the user's phone number
        public string? PhoneNumber { get; set; }

        // Property to hold the user's city
        public string? City { get; set; }

        // Property to hold the user's country
        public string? Country { get; set; }

        // Property to hold the user's name
        public string? Name { get; set; }

        // Property to hold the user's email
        public string? Email { get; set; }
    }
}
