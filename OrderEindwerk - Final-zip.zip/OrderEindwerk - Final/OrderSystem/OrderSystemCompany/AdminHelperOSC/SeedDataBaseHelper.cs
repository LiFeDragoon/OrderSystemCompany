﻿using Microsoft.AspNetCore.Identity;
using OrderSystemCompany.Objects;

namespace OrderSystemCompany.UI.AdminHelperOSC
{
    public class SeedDataBaseHelper
    {
        // Seed roles and admin user in the database
        public static async Task SeedRolesAndAdmin(IServiceProvider service)
        {
            // Seed Roles
            var userManager = service.GetService<UserManager<User>>();
            var roleManager = service.GetService<RoleManager<IdentityRole>>();

            // Add two roles: Admin and User
            await roleManager.CreateAsync(new IdentityRole(AdminRoles.Admin.ToString()));
            await roleManager.CreateAsync(new IdentityRole(AdminRoles.User.ToString()));

            // Create admin user
            var user = new User
            {
                UserName = "admin@gmail.com",
                Email = "admin@gmail.com",
                Address = "TestAddress",
                City = "Testcity",
                PostalCode = "9000",
                Country = "BE",
                Name = "admin",
                EmailConfirmed = true,
                PhoneNumberConfirmed = true
            };

            var userInDb = await userManager.FindByEmailAsync(user.Email);
            // Check if the admin user already exists in the database
            if (userInDb != null)
            {
                return; // If the user already exists, return without further action
            }

            await userManager.CreateAsync(user, "Testing*123"); // Create the admin user with a password
            await userManager.AddToRoleAsync(user, AdminRoles.Admin.ToString()); // Assign the admin role to the user
        }
    }
}
