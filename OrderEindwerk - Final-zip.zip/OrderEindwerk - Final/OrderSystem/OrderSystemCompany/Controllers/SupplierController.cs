﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OrderSystemCompany.DA;
using OrderSystemCompany.Objects;

namespace OrderSystemCompany.UI.Controllers
{
    public class SupplierController : Controller
    {
        private readonly Repository _context;

        public SupplierController(Repository context)
        {
            _context = context;
        }

        // GET: Supplier
        public async Task<IActionResult> Index()
        {
            try
            {
                // Check if the supplier entity set is null
                if (_context.Supplier == null)
                {
                    return Problem("Entity set 'Repository.Supplier' is null.");
                }

                // Retrieve all suppliers and pass them to the view
                return View(await _context.Supplier.ToListAsync());
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // GET: Supplier/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            try
            {
                if (id == null || _context.Supplier == null)
                {
                    return NotFound();
                }

                // Retrieve the supplier by ID
                var supplier = await _context.Supplier
                    .FirstOrDefaultAsync(m => m.Supplier_Id == id);

                if (supplier == null)
                {
                    return NotFound();
                }

                return View(supplier);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // GET: Supplier/Create
        public IActionResult Create()
        {
            try
            {
                return View();
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // POST: Supplier/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Supplier_Id,Supplier_Name,Supplier_Address,Supplier_City,Supplier_Country,Supplier_PostalCode,Supplier_Phone,Supplier_Email")] Supplier supplier)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    // Add the new supplier and save changes
                    _context.Add(supplier);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }

                return View(supplier);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // GET: Supplier/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            try
            {
                if (id == null || _context.Supplier == null)
                {
                    return NotFound();
                }

                // Retrieve the supplier by ID
                var supplier = await _context.Supplier.FindAsync(id);

                if (supplier == null)
                {
                    return NotFound();
                }

                return View(supplier);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // POST: Supplier/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Supplier_Id,Supplier_Name,Supplier_Address,Supplier_City,Supplier_Country,Supplier_PostalCode,Supplier_Phone,Supplier_Email")] Supplier supplier)
        {
            try
            {
                if (id != supplier.Supplier_Id)
                {
                    return NotFound();
                }

                if (ModelState.IsValid)
                {
                    try
                    {
                        // Update the supplier and save changes
                        _context.Update(supplier);
                        await _context.SaveChangesAsync();
                    }
                    catch (DbUpdateConcurrencyException)
                    {
                        if (!SupplierExists(supplier.Supplier_Id))
                        {
                            return NotFound();
                        }
                        else
                        {
                            throw;
                        }
                    }

                    return RedirectToAction(nameof(Index));
                }

                return View(supplier);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // GET: Supplier/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            try
            {
                if (id == null || _context.Supplier == null)
                {
                    return NotFound();
                }

                // Retrieve the supplier by ID
                var supplier = await _context.Supplier
                    .FirstOrDefaultAsync(m => m.Supplier_Id == id);

                if (supplier == null)
                {
                    return NotFound();
                }

                return View(supplier);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // POST: Supplier/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            try
            {
                if (_context.Supplier == null)
                {
                    return Problem("Entity set 'Repository.Supplier' is null.");
                }

                // Retrieve the supplier by ID and remove it
                var supplier = await _context.Supplier.FindAsync(id);

                if (supplier != null)
                {
                    _context.Supplier.Remove(supplier);
                }

                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        private bool SupplierExists(int id)
        {
            // Check if a supplier with the given ID exists
            return (_context.Supplier?.Any(e => e.Supplier_Id == id)).GetValueOrDefault();
        }
    }
}
