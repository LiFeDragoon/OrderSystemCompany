﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using OrderSystemCompany.DA;
using OrderSystemCompany.Objects;
using OrderSystemCompany.Services;

namespace OrderSystemCompany.UI.Controllers
{
    public class MessagesController : Controller
    {
        private readonly Microsoft.AspNetCore.Identity.UserManager<User> _userManager;
        private MessagesServices _messageService { get; set; }
        private UserServices _userService { get; set; }
        private readonly Repository _context = new Repository();

        public MessagesController(MessagesServices messagesServices, UserServices userServices, Microsoft.AspNetCore.Identity.UserManager<User> userManager, Repository context)
        {
            _messageService = messagesServices;
            _userService = userServices;
            _userManager = userManager;
            _context = context;
        }

        // GET: /Messages/Index
        public IActionResult Index()
        {
            try
            {
                // Get the list of messages
                var list = _messageService.GetMessage();

                // Check if there is a temporary message in TempData
                if (TempData.ContainsKey("message"))
                {
                    ViewBag.Message = TempData["message"].ToString();
                }

                // Iterate through the list of messages
                foreach (var message in list)
                {
                    // Get the user associated with the message
                    var user = _userService.GetUserById(message.User_Id);
                    // Set the User_Id property of the message to the username if the user exists, otherwise an empty string
                    message.User_Id = user != null ? user.UserName : "";
                }

                // Render the Index view with the list of messages
                return View(list);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                // You can customize this according to your logging requirements
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // GET: /Messages/Details/5
        public IActionResult Details(int id)
        {
            try
            {
                // Get the message by its id
                var message = _messageService.GetMessagesById(id);

                // Check if there is a temporary message in TempData
                if (TempData.ContainsKey("message"))
                {
                    ViewBag.Message = TempData["Message"].ToString();
                }

                // Get the current user's id
                var userId = _userManager.GetUserId(User);
                // Get the message to be displayed
                var showMessage = _messageService.GetMessagesById(id);

                // If the user is logged in, get the username and pass it to the view
                if (userId != null)
                {
                    var user = _userService.GetUserById(userId);
                    var userName = user.UserName;

                    ViewData["UserId"] = userId;
                    ViewData["UserName"] = userName;
                }
                else
                {
                    ViewData["UserId"] = "";
                    ViewData["UserName"] = "";
                }

                // Render the Details view with the message
                return View(message);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                // You can customize this according to your logging requirements
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // GET: /Messages/Delete/5
        public IActionResult Delete(int id)
        {
            try
            {
                // Get the message to be deleted
                var messageToDelete = _messageService.GetMessagesById(id);

                // Render the Delete view with the message
                return View(messageToDelete);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                // You can customize this according to your logging requirements
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // POST: /Messages/Delete/5
        [HttpPost]
        public IActionResult Delete(int id, Messages messages)
        {
            try
            {
                // Delete the message
                _messageService.DeleteMessage(id);
                TempData["message"] = "Object has been deleted successfully.";

                // Redirect to the Index action
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                // You can customize this according to your logging requirements
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // GET: /Messages/Edit/5
        public IActionResult Edit(int id)
        {
            try
            {
                // Get the current user's id
                var userId = _userManager.GetUserId(User);
                // Get the message to be edited
                var showMessage = _messageService.GetMessagesById(id);

                // If the user is logged in, get the username and pass it to the view
                if (userId != null)
                {
                    var user = _userService.GetUserById(userId);
                    var userName = user.UserName;

                    ViewData["UserId"] = userId;
                    ViewData["UserName"] = userName;
                }
                else
                {
                    ViewData["UserId"] = "";
                    ViewData["UserName"] = "";
                }

                // Render the Edit view with the message
                return View(showMessage);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                // You can customize this according to your logging requirements
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // POST: /Messages/Edit
        [HttpPost]
        public IActionResult Edit(Messages messages)
        {
            try
            {
                // Get the current user's id
                var userId = _userManager.GetUserId(User);

                // If the user is logged in, get the username and pass it to the view
                if (userId != null)
                {
                    var user = _userService.GetUserById(userId);
                    var userName = user.UserName;

                    ViewData["UserId"] = userId;
                    ViewData["UserName"] = userName;

                    messages.User_Id = userId;
                }
                else
                {
                    ViewData["UserId"] = "";
                    ViewData["UserName"] = "";
                }

                // Create or update the message
                _messageService.CreateOrUpdateMessage(messages);
                TempData["message"] = "Object has been updated successfully.";

                // Redirect to the Index action
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                // You can customize this according to your logging requirements
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // GET: /Messages/Create
        public IActionResult Create()
        {
            try
            {
                // Pass the list of message dates to the view
                ViewData["Message_Date"] = new SelectList(_context.Messages, "Message_Date", "Message_Date");

                // Get the current user's id
                var userId = _userManager.GetUserId(User);

                // If the user is logged in, get the username and pass it to the view
                if (userId != null)
                {
                    var user = _userService.GetUserById(userId);
                    var userName = user.UserName;

                    ViewData["UserId"] = userId;
                    ViewData["UserName"] = userName;
                }
                else
                {
                    ViewData["UserId"] = "";
                    ViewData["UserName"] = "";
                }

                // Render the Create view
                return View();
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                // You can customize this according to your logging requirements
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // POST: /Messages/Create
        [HttpPost]
        public IActionResult Create(Messages messages)
        {
            try
            {
                // Get the current user's id
                var userId = _userManager.GetUserId(User);

                // If the user is logged in, get the username and pass it to the view
                if (userId != null)
                {
                    var user = _userService.GetUserById(userId);
                    var userName = user.UserName;

                    ViewData["UserId"] = userId;
                    ViewData["UserName"] = userName;

                    messages.User_Id = userId;
                }
                else
                {
                    ViewData["UserId"] = "";
                    ViewData["UserName"] = "";
                }

                // Create or update the message
                _messageService.CreateOrUpdateMessage(messages);
                TempData["message"] = "Object has been created successfully.";

                // Redirect to the Index action with the message id
                return RedirectToAction("Index", new { id = messages.Message_Id });
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                // You can customize this according to your logging requirements
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }
    }
}
