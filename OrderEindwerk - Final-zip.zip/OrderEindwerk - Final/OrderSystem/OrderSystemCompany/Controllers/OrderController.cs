﻿using Microsoft.AspNetCore.Mvc;
using OrderSystemCompany.Objects;
using OrderSystemCompany.Services;

public class OrderController : Controller
{
    private readonly Microsoft.AspNetCore.Identity.UserManager<User> _userManager;
    private OrderServices _orderService { get; set; }
    private UserServices _userService { get; set; }
    private CustomerFileServices _customerFileService { get; set; }

    public OrderController(OrderServices orderService, UserServices userServices, Microsoft.AspNetCore.Identity.UserManager<User> userManager, CustomerFileServices customerFileService)
    {
        // Initialize the dependencies through dependency injection
        _orderService = orderService;
        _userService = userServices;
        _userManager = userManager;
        _customerFileService = customerFileService;
    }

    public IActionResult Index()
    {
        try
        {
            // Retrieve the list of orders
            var list = _orderService.GetOrder();

            if (TempData.ContainsKey("message"))
            {
                ViewBag.Message = TempData["Message"].ToString();
            }

            foreach (var order in list)
            {
                var user = _userService.GetUserById(order.User_Id);
                order.User_Id = user != null ? user.UserName : "";
            }

            // Pass the list of orders to the view
            return View(list);
        }
        catch (Exception ex)
        {
            // Handle and log the exception
            Console.WriteLine($"An error occurred: {ex}");
            return StatusCode(500, "An error occurred while processing the request.");
        }
    }

    public IActionResult Details(int id)
    {
        try
        {
            var userId = _userManager.GetUserId(User);
            var order = _orderService.GetOrderById(id);

            if (userId != null)
            {
                var user = _userService.GetUserById(userId);
                var userName = user.Name;

                ViewData["UserId"] = userId;
                ViewData["UserName"] = userName;
            }
            else
            {
                ViewData["UserId"] = "";
                ViewData["UserName"] = "";
            }

            if (TempData.ContainsKey("message"))
            {
                ViewBag.Message = TempData["Message"].ToString();
            }

            // Pass the order to the view
            return View(order);
        }
        catch (Exception ex)
        {
            // Handle and log the exception
            Console.WriteLine($"An error occurred: {ex}");
            return StatusCode(500, "An error occurred while processing the request.");
        }
    }

    public IActionResult Edit(int id)
    {
        try
        {
            var showOrder = _orderService.GetOrderById(id);
            var userId = _userManager.GetUserId(User);

            if (userId != null)
            {
                var user = _userService.GetUserById(userId);
                var userName = user.Name;

                ViewData["UserId"] = userId;
                ViewData["UserName"] = userName;
            }
            else
            {
                ViewData["UserId"] = "";
                ViewData["UserName"] = "";
            }

            // Pass the order to the view
            return View(showOrder);
        }
        catch (Exception ex)
        {
            // Handle and log the exception
            Console.WriteLine($"An error occurred: {ex}");
            return StatusCode(500, "An error occurred while processing the request.");
        }
    }

    [HttpPost]
    public IActionResult Edit(Order order)
    {
        try
        {
            var userId = _userManager.GetUserId(User);

            if (userId != null)
            {
                var user = _userService.GetUserById(userId);
                var userName = user.Name;

                ViewData["UserId"] = userId;
                ViewData["UserName"] = userName;

                order.User_Id = userId;
            }
            else
            {
                ViewData["UserId"] = "";
                ViewData["UserName"] = "";
            }

            // Update the order
            _orderService.CreateOrUpdateOrder(order);

            TempData["message"] = "Object has been updated successfully.";

            return RedirectToAction("Index");
        }
        catch (Exception ex)
        {
            // Handle and log the exception
            Console.WriteLine($"An error occurred: {ex}");
            return StatusCode(500, "An error occurred while processing the request.");
        }
    }

    public IActionResult Create()
    {
        try
        {
            var userId = _userManager.GetUserId(User);

            if (userId != null)
            {
                var user = _userService.GetUserById(userId);
                var userName = user.Name;

                ViewData["UserId"] = userId;
                ViewData["UserName"] = userName;
            }
            else
            {
                ViewData["UserId"] = "";
                ViewData["UserName"] = "";
            }

            // Render the Create view
            return View();
        }
        catch (Exception ex)
        {
            // Handle and log the exception
            Console.WriteLine($"An error occurred: {ex}");
            return StatusCode(500, "An error occurred while processing the request.");
        }
    }

    [HttpPost]
    public IActionResult Create(Order order)
    {
        try
        {
            var userId = _userManager.GetUserId(User);

            if (userId != null)
            {
                var user = _userService.GetUserById(userId);
                var userName = user.Name;

                ViewData["UserId"] = userId;
                ViewData["UserName"] = userName;

                order.User_Id = userId;
            }
            else
            {
                ViewData["UserId"] = "";
                ViewData["UserName"] = "";
            }

            // Create the order
            _orderService.CreateOrUpdateOrder(order);

            TempData["message"] = "Object has been created successfully.";

            return RedirectToAction("Details", new { id = order.Order_Id });
        }
        catch (Exception ex)
        {
            // Handle and log the exception
            Console.WriteLine($"An error occurred: {ex}");
            return StatusCode(500, "An error occurred while processing the request.");
        }
    }

    public IActionResult Delete(int id)
    {
        try
        {
            var orderToDelete = _orderService.GetOrderById(id);

            // Render the Delete view with the order to be deleted
            return View(orderToDelete);
        }
        catch (Exception ex)
        {
            // Handle and log the exception
            Console.WriteLine($"An error occurred: {ex}");
            return StatusCode(500, "An error occurred while processing the request.");
        }
    }

    [HttpPost]
    public IActionResult Delete(int id, Order order)
    {
        try
        {
            // Delete the order
            _orderService.DeleteOrder(id);

            TempData["message"] = "Object has been deleted successfully.";

            return RedirectToAction("Index");
        }
        catch (Exception ex)
        {
            // Handle and log the exception
            Console.WriteLine($"An error occurred: {ex}");
            return StatusCode(500, "An error occurred while processing the request.");
        }
    }
}
