﻿using Microsoft.AspNetCore.Mvc;
using OrderSystemCompany.Objects;
using OrderSystemCompany.Services;

public class CustomerFileController : Controller
{
    private readonly CustomerFileServices _customerFileServices;

    public CustomerFileController(CustomerFileServices customerFileServices)
    {
        _customerFileServices = customerFileServices;
    }

    // GET: /CustomerFile/Index
    public IActionResult Index()
    {
        try
        {
            // Retrieve the customer files from the service
            var customerFiles = _customerFileServices.GetCustomerFile();

            // Pass the customer files to the view and render the Index view
            return View(customerFiles);
        }
        catch (Exception ex)
        {
            // Handle and log the exception
            // You can customize this according to your logging requirements
            Console.WriteLine($"An error occurred: {ex}");
            return StatusCode(500, "An error occurred while processing the request.");
        }
    }

    // GET: /CustomerFile/Details/5
    public IActionResult Details(int id)
    {
        try
        {
            // Retrieve the customer file with the specified ID from the service
            var customerFile = _customerFileServices.GetCustomerFileById(id);

            // If the customer file is not found, return "Not Found" status
            if (customerFile == null)
            {
                return NotFound();
            }

            // Pass the customer file to the view and render the Details view
            return View(customerFile);
        }
        catch (Exception ex)
        {
            // Handle and log the exception
            // You can customize this according to your logging requirements
            Console.WriteLine($"An error occurred: {ex}");
            return StatusCode(500, "An error occurred while processing the request.");
        }
    }

    // GET: /CustomerFile/Create
    public IActionResult Create()
    {
        // Render the Create view
        return View();
    }

    // POST: /CustomerFile/Create
    [HttpPost]
    public IActionResult Create(CustomerFile customerFile)
    {
        try
        {
            // Check if the model state is valid
            if (ModelState.IsValid)
            {
                // Create or update the customer file using the service
                _customerFileServices.CreateOrUpdateCustomerFile(customerFile);

                // Redirect to the Index action of the CustomerFile controller
                return RedirectToAction(nameof(Index));
            }

            // If the model state is invalid, re-render the Create view with the model
            return View(customerFile);
        }
        catch (Exception ex)
        {
            // Handle and log the exception
            // You can customize this according to your logging requirements
            Console.WriteLine($"An error occurred: {ex}");
            return StatusCode(500, "An error occurred while processing the request.");
        }
    }

    // GET: /CustomerFile/Edit/5
    public IActionResult Edit(int id)
    {
        try
        {
            // Retrieve the customer file with the specified ID from the service
            var customerFile = _customerFileServices.GetCustomerFileById(id);

            // If the customer file is not found, return "Not Found" status
            if (customerFile == null)
            {
                return NotFound();
            }

            // Pass the customer file to the view and render the Edit view
            return View(customerFile);
        }
        catch (Exception ex)
        {
            // Handle and log the exception
            // You can customize this according to your logging requirements
            Console.WriteLine($"An error occurred: {ex}");
            return StatusCode(500, "An error occurred while processing the request.");
        }
    }

    // POST: /CustomerFile/Edit/5
    [HttpPost]
    public IActionResult Edit(int id, CustomerFile customerFile)
    {
        try
        {
            // Check if the provided ID matches the customer file's ID, return "Not Found" if not
            if (id != customerFile.CustomerFile_Id)
            {
                return NotFound();
            }

            // Check if the model state is valid
            if (ModelState.IsValid)
            {
                // Create or update the customer file using the service
                _customerFileServices.CreateOrUpdateCustomerFile(customerFile);

                // Redirect to the Index action of the CustomerFile controller
                return RedirectToAction(nameof(Index));
            }

            // If the model state is invalid, re-render the Edit view with the model
            return View(customerFile);
        }
        catch (Exception ex)
        {
            // Handle and log the exception
            // You can customize this according to your logging requirements
            Console.WriteLine($"An error occurred: {ex}");
            return StatusCode(500, "An error occurred while processing the request.");
        }
    }

    // GET: /CustomerFile/Delete/5
    public IActionResult Delete(int id)
    {
        try
        {
            // Retrieve the customer file with the specified ID from the service
            var customerFile = _customerFileServices.GetCustomerFileById(id);

            // If the customer file is not found, return "Not Found" status
            if (customerFile == null)
            {
                return NotFound();
            }

            // Pass the customer file to the view and render the Delete view
            return View(customerFile);
        }
        catch (Exception ex)
        {
            // Handle and log the exception
            // You can customize this according to your logging requirements
            Console.WriteLine($"An error occurred: {ex}");
            return StatusCode(500, "An error occurred while processing the request.");
        }
    }

    // POST: /CustomerFile/Delete/5
    [HttpPost, ActionName("Delete")]
    public IActionResult DeleteConfirmed(int id)
    {
        try
        {
            // Delete the customer file with the specified ID using the service
            var result = _customerFileServices.DeleteCustomerFile(id);

            // If the deletion was not successful, return "Not Found" status
            if (!result)
            {
                return NotFound();
            }

            // Redirect to the Index action of the CustomerFile controller
            return RedirectToAction(nameof(Index));
        }
        catch (Exception ex)
        {
            // Handle and log the exception
            // You can customize this according to your logging requirements
            Console.WriteLine($"An error occurred: {ex}");
            return StatusCode(500, "An error occurred while processing the request.");
        }
    }
}
