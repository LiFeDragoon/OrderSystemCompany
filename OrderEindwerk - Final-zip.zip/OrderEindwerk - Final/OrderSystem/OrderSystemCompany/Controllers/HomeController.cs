﻿using Microsoft.AspNetCore.Mvc;
using OrderSystemCompany.Models;
using OrderSystemCompany.Services;
using System.Diagnostics;

namespace OrderSystemCompany.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly MessagesServices _messagesServices;
        private readonly StatusMessagesServices _statusMessagesServices;

        public HomeController(ILogger<HomeController> logger, MessagesServices messagesServices, StatusMessagesServices statusMessagesServices)
        {
            _logger = logger;
            _messagesServices = messagesServices;
            _statusMessagesServices = statusMessagesServices;
        }

        // GET: /Home/Index
        public IActionResult Index()
        {
            // Get the last added message from the Messages controller or data source
            var lastMessage = _messagesServices.GetMessageFromMessagesController();
            var lastStatusMessage = _statusMessagesServices.GetStatusMessageFromStatusMessagesController();

            // Pass the last message to the view using ViewBag
            ViewBag.LastMessage = lastMessage;
            ViewBag.LastStatusMessage = lastStatusMessage;

            // Render the Index view
            return View();
        }

        // GET: /Home/Privacy
        public IActionResult Privacy()
        {
            // Render the Privacy view
            return View();
        }

        // GET: /Home/Error
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            // Create an ErrorViewModel and set its RequestId property
            var errorViewModel = new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier };

            // Render the Error view with the ErrorViewModel
            return View(errorViewModel);
        }
    }
}
