﻿using Microsoft.AspNetCore.Mvc;
using OrderSystemCompany.DA;
using OrderSystemCompany.Objects;
using OrderSystemCompany.Services;

namespace OrderSystemCompany.UI.Controllers
{
    public class StatusMessagesController : Controller
    {
        private readonly Microsoft.AspNetCore.Identity.UserManager<User> _userManager;
        private StatusMessagesServices _statusMessageService { get; set; }
        private UserServices _userService { get; set; }
        private readonly Repository _context = new Repository();

        public StatusMessagesController(StatusMessagesServices statusMessagesServices, UserServices userServices, Microsoft.AspNetCore.Identity.UserManager<User> userManager, Repository context)
        {
            // Initialize dependencies through dependency injection
            _statusMessageService = statusMessagesServices;
            _userService = userServices;
            _userManager = userManager;
            _context = context;
        }

        // GET: StatusMessages
        public IActionResult Index()
        {
            try
            {
                // Retrieve all status messages
                var list = _statusMessageService.GetAllStatusMessages();

                if (TempData.ContainsKey("message"))
                {
                    ViewBag.Message = TempData["message"].ToString();
                }

                foreach (var message in list)
                {
                    // Retrieve the user associated with each status message and update the User_Id property with the user's username
                    var user = _userService.GetUserById(message.User_Id);
                    message.User_Id = user != null ? user.UserName : "";
                }

                return View(list);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // GET: StatusMessages/Details/5
        public IActionResult Details(int id)
        {
            try
            {
                // Retrieve the status message by ID
                var message = _statusMessageService.GetStatusMessageById(id);
                if (TempData.ContainsKey("message"))
                {
                    ViewBag.Message = TempData["Message"].ToString();
                }
                var userId = _userManager.GetUserId(User);
                var ShowMessage = _statusMessageService.GetStatusMessageById(id);
                if (userId != null)
                {
                    var user = _userService.GetUserById(userId);
                    var userName = user.UserName;

                    ViewData["UserId"] = userId;
                    ViewData["UserName"] = userName;
                }
                else
                {
                    ViewData["UserId"] = "";
                    ViewData["UserName"] = "";
                }

                return View(message);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // GET: StatusMessages/Delete/5
        public IActionResult Delete(int id)
        {
            try
            {
                // Retrieve the status message to delete
                var messagetodelete = _statusMessageService.GetStatusMessageById(id);
                return View(messagetodelete);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // POST: StatusMessages/Delete/5
        [HttpPost]
        public IActionResult Delete(int id, StatusMessages statusMessages)
        {
            try
            {
                // Delete the status message
                _statusMessageService.DeleteStatusMessage(id);
                TempData["message"] = "Object has been deleted successfully.";

                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // GET: StatusMessages/Edit/5
        public IActionResult Edit(int id)
        {
            try
            {
                var userId = _userManager.GetUserId(User);
                var ShowMessage = _statusMessageService.GetStatusMessageById(id);
                if (userId != null)
                {
                    var user = _userService.GetUserById(userId);
                    var userName = user.UserName;

                    ViewData["UserId"] = userId;
                    ViewData["UserName"] = userName;
                }
                else
                {
                    ViewData["UserId"] = "";
                    ViewData["UserName"] = "";
                }
                return View(ShowMessage);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // POST: StatusMessages/Edit/5
        [HttpPost]
        public IActionResult Edit(StatusMessages statusMessages)
        {
            try
            {
                var userId = _userManager.GetUserId(User);
                if (userId != null)
                {
                    var user = _userService.GetUserById(userId);
                    var userName = user.UserName;

                    ViewData["UserId"] = userId;
                    ViewData["UserName"] = userName;

                    statusMessages.User_Id = userId;
                }
                else
                {
                    ViewData["UserId"] = "";
                    ViewData["UserName"] = "";
                }
                // Create or update the status message
                _statusMessageService.CreateOrUpdateStatusMessage(statusMessages);
                TempData["message"] = "Object has been updated successfully.";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // GET: StatusMessages/Create
        public IActionResult Create()
        {
            try
            {
                // Initialize a new status message object
                var statusMessages = new StatusMessages();
                statusMessages.StatusMessage_NotUrgent = false;
                statusMessages.StatusMessage_Urgent = false;
                statusMessages.StatusMessage_Priority = false;
                var userId = _userManager.GetUserId(User);
                if (userId != null)
                {
                    var user = _userService.GetUserById(userId);
                    var userName = user.UserName;

                    ViewData["UserId"] = userId;
                    ViewData["UserName"] = userName;
                }
                else
                {
                    ViewData["UserId"] = "";
                    ViewData["UserName"] = "";
                }

                return View(statusMessages);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // POST: StatusMessages/Create
        [HttpPost]
        public IActionResult Create(StatusMessages statusMessages)
        {
            try
            {
                var userId = _userManager.GetUserId(User);
                if (userId != null)
                {
                    var user = _userService.GetUserById(userId);
                    var userName = user.UserName;

                    ViewData["UserId"] = userId;
                    ViewData["UserName"] = userName;

                    statusMessages.User_Id = userId;
                }
                else
                {
                    ViewData["UserId"] = "";
                    ViewData["UserName"] = "";
                }

                // Create or update the status message
                _statusMessageService.CreateOrUpdateStatusMessage(statusMessages);
                TempData["message"] = "Object has been created successfully.";

                return RedirectToAction("Index", new { id = statusMessages.StatusMessage_Id });
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }
    }
}
