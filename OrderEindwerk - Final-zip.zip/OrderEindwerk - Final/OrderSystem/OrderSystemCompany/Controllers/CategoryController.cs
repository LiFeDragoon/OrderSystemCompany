﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OrderSystemCompany.DA;
using OrderSystemCompany.Objects;

namespace OrderSystemCompany.UI.Controllers
{
    public class CategoryController : Controller
    {
        private readonly Repository _context;

        public CategoryController(Repository context)
        {
            _context = context;
        }

        // GET: Category
        public async Task<IActionResult> Index()
        {
            try
            {
                // Retrieve the list of categories from the database, or return an error message if the entity set is null
                return _context.Category != null ?
                           View(await _context.Category.ToListAsync()) :
                           Problem("Entity set 'Repository.Category' is null.");
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                // You can customize this according to your logging requirements
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // get create
        public IActionResult Create()
        {
            try
            {
                // Return the create category view
                return View();
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                // You can customize this according to your logging requirements
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // POST: Category/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        public async Task<IActionResult> Create([Bind("Cat_Id,Cat_Name")] Category category)
        {
            try
            {
                // Check if the model state is valid
                if (ModelState.IsValid)
                {
                    // Add the category to the entity set and save changes to the database
                    _context.Add(category);
                    await _context.SaveChangesAsync();

                    // Redirect to the index action of the category controller
                    return RedirectToAction(nameof(Index));
                }

                // Return the create category view with the model if the model state is invalid
                return View(category);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                // You can customize this according to your logging requirements
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        //get edit
        public async Task<IActionResult> Edit(int? id)
        {
            try
            {
                // Check if the provided ID is null, return "Not Found" if it is
                if (id == null)
                {
                    return NotFound();
                }

                // Retrieve the category by ID
                var category = await _context.Category.FindAsync(id);

                // Check if the category is null, return "Not Found" if it is
                if (category == null)
                {
                    return NotFound();
                }

                // Return the edit category view with the retrieved category
                return View(category);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                // You can customize this according to your logging requirements
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // POST: Category/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]

        public async Task<IActionResult> Edit(int id, [Bind("Cat_Id,Cat_Name")] Category category)
        {
            try
            {
                // Check if the provided ID matches the category ID, return "Not Found" if not
                if (id != category.Cat_Id)
                {
                    return NotFound();
                }

                // Check if the model state is valid
                if (ModelState.IsValid)
                {
                    try
                    {
                        // Update the category in the entity set and save changes to the database
                        _context.Update(category);
                        await _context.SaveChangesAsync();
                    }
                    catch (DbUpdateConcurrencyException)
                    {
                        // If a concurrency exception occurs, check if the category still exists, and throw an exception if not
                        if (!CategoryExists(category.Cat_Id))
                        {
                            return NotFound();
                        }
                        else
                        {
                            throw;
                        }
                    }

                    // Redirect to the index action of the category controller
                    return RedirectToAction(nameof(Index));
                }

                // Return the edit category view with the model if the model state is invalid
                return View(category);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                // You can customize this according to your logging requirements
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        //get delete
        public async Task<IActionResult> Delete(int? id)
        {
            try
            {
                // Check if the provided ID is null, return "Not Found" if it is
                if (id == null)
                {
                    return NotFound();
                }

                // Retrieve the category by ID
                var category = await _context.Category
                    .FirstOrDefaultAsync(m => m.Cat_Id == id);

                // Check if the category is null, return "Not Found" if it is
                if (category == null)
                {
                    return NotFound();
                }

                // Return the delete category view with the retrieved category
                return View(category);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                // You can customize this according to your logging requirements
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // POST: Category/Delete/5
        [HttpPost, ActionName("Delete")]

        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                // Check if the entity set is null, return an error message if true
                if (_context.Category == null)
                {
                    return Problem("Entity set 'Repository.Category' is null.");
                }

                // Retrieve the category with the specified ID from the database
                var category = await _context.Category.FindAsync(id);

                // If the category exists, remove it from the entity set and save changes to the database
                if (category != null)
                {
                    _context.Category.Remove(category);
                }

                await _context.SaveChangesAsync();

                // Redirect to the index action of the category controller
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                // You can customize this according to your logging requirements
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // ... (Other actions omitted for brevity)

        // Check if a category with the specified ID exists in the entity set
        private bool CategoryExists(int id)
        {
            return (_context.Category?.Any(e => e.Cat_Id == id)).GetValueOrDefault();
        }

        //get details
        public async Task<IActionResult> Details(int? id)
        {
            try
            {
                // Check if the provided ID is null, return "Not Found" if it is
                if (id == null)
                {
                    return NotFound();
                }

                // Retrieve the category by ID
                var category = await _context.Category
                    .FirstOrDefaultAsync(m => m.Cat_Id == id);

                // Check if the category is null, return "Not Found" if it is
                if (category == null)
                {
                    return NotFound();
                }

                // Return the details category view with the retrieved category
                return View(category);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                // You can customize this according to your logging requirements
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        //put details

        [HttpPut("{id}")]
        public async Task<IActionResult> PutCategory(int id, Category category)
        {
            try
            {
                // Check if the provided ID matches the category ID, return "Not Found" if not
                if (id != category.Cat_Id)
                {
                    return BadRequest();
                }

                // Check if the model state is valid
                if (ModelState.IsValid)
                {
                    try
                    {
                        // Update the category in the entity set and save changes to the database
                        _context.Update(category);
                        await _context.SaveChangesAsync();
                    }
                    catch (DbUpdateConcurrencyException)
                    {
                        // If a concurrency exception occurs, check if the category still exists, and throw an exception if not
                        if (!CategoryExists(category.Cat_Id))
                        {
                            return NotFound();
                        }
                        else
                        {
                            throw;
                        }
                    }

                    // Redirect to the index action of the category controller
                    return RedirectToAction(nameof(Index));
                }

                // Return the edit category view with the model if the model state is invalid
                return View(category);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                // You can customize this according to your logging requirements
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }
    }
}
