﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using OrderSystemCompany.DA;
using OrderSystemCompany.Objects;
using OrderSystemCompany.Services;
using OrderSystemCompany.UI.Models;

namespace OrderSystemCompany.UI.Controllers
{
    public class OrderDetailsController : Controller
    {
        private readonly Repository _context;
        private readonly OrderDetailsServices orderDetailsServices;
        private readonly OrderServices orderServices;
        private readonly UserManager<User> _userManager;
        private readonly CustomerFileServices _customerFileServices;

        public OrderDetailsController(Repository context, OrderServices orderService, OrderDetailsServices orderDetailsService, UserManager<User> userManager, CustomerFileServices customerFile)
        {
            // Initialize dependencies through dependency injection
            _context = context;
            orderDetailsServices = orderDetailsService;
            orderServices = orderService;
            _userManager = userManager;
            _customerFileServices = customerFile;
        }

        // GET: OrderDetails by id to create index
        public IActionResult Index()
        {
            try
            {
                var list = orderDetailsServices.GetOrderDetails();

                if (TempData.TryGetValue("message", out object? value))
                {
                    ViewBag.Message = value.ToString();
                }
                else
                {
                    TempData["Message"] = "Order Details have not been created.";
                }

                // Retrieve the user name from the first OrderDetails object in the list (assuming there is at least one object)
                string userName = list.FirstOrDefault()?.Order?.User?.UserName;

                // Pass the user name to the view
                ViewBag.UserName = userName;

                return View(list);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // Get the order details to create details
        public IActionResult Details(int id)
        {
            try
            {
                var orderDetails = orderDetailsServices.GetOrderDetailsById(id);
                if (TempData.ContainsKey("message"))
                {
                    ViewBag.Message = TempData["Message"].ToString();
                }
                else
                {
                    TempData["Message"] = "Order Details have not been created.";
                }

                // Retrieve the user name from the OrderDetails object
                string userName = orderDetails.Order?.User?.UserName;

                // Pass the user name to the view
                ViewBag.UserName = userName;

                return View(orderDetails);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        public IActionResult Create()
        {
            try
            {
                // View all in GetOrderDetails
                ViewData["Order_Id"] = new SelectList(_context.Order, "Order_Id", "User_Id");
                ViewData["Order_Date"] = new SelectList(_context.Order, "Order_Date", "Order_Date");
                ViewData["Order_ShipDate"] = new SelectList(_context.Order, "Order_ShipDate", "Order_ShipDate");
                ViewData["CustomerFile_Id"] = new SelectList(_context.CustomerFile, "CustomerFile_Id", "CustomerFile_Name");

                // Get ViewData from User ID into the ViewBag, otherwise return null
                var id1 = _userManager.GetUserId(User);
                if (id1 != null)
                {
                    ViewData["UserId"] = id1;
                }
                else
                {
                    ViewData["UserId"] = "";
                }

                ViewData["StProduct_Id"] = new SelectList(_context.StockProduct, "StProduct_Id", "StProduct_Name");
                ViewData["StProduct_UnitInStock"] = new SelectList(_context.StockProduct, "StProduct_UnitInStock", "StProduct_UnitInStock");
                ViewData["StProduct_Price"] = new SelectList(_context.StockProduct, "StProduct_Price", "StProduct_Price");
                ViewData["StProduct_Discription"] = new SelectList(_context.StockProduct, "StProduct_Discription", "StProduct_Discription");

                var model = new OrderDetailsModel();

                return View(model);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // POST: OrderDetails/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        // Create by GetOrderDetails
        public IActionResult Create(OrderDetailsModel PRorderDetails)
        {
            try
            {
                // Check if user id is not null, otherwise show message
                if (PRorderDetails.order.User_Id == null)
                {
                    TempData["Message"] = "User Id is not valid";
                    return RedirectToAction("Index");
                }

                ViewData["StProduct_Id"] = new SelectList(_context.StockProduct, "StProduct_Id", "StProduct_Name");

                // Create or update the order and order details
                orderServices.CreateOrUpdateOrder(PRorderDetails.order);
                PRorderDetails.orderDetails.Order_Id = PRorderDetails.order.Order_Id;
                orderDetailsServices.CreateOrUpdateOrderDetails(PRorderDetails.orderDetails);

                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // GET: OrderDetails/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            try
            {
                if (id == null || _context.OrderDetails == null)
                {
                    return NotFound();
                }

                var orderDetails = await _context.OrderDetails
                    .Include(o => o.Order)
                    .Include(o => o.StockProduct)
                    .FirstOrDefaultAsync(m => m.Order_Id == id);
                if (orderDetails == null)
                {
                    return NotFound();
                }

                return View(orderDetails);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // POST: OrderDetails/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            try
            {
                if (_context.OrderDetails == null)
                {
                    return Problem("Entity set 'Repository.OrderDetails' is null.");
                }

                var orderDetails = await _context.OrderDetails.FindAsync(id);
                if (orderDetails != null)
                {
                    _context.OrderDetails.Remove(orderDetails);
                }

                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // Edit by using the services
        public IActionResult Edit(int id)
        {
            try
            {
                var orderDetails = orderDetailsServices.GetOrderDetailsById(id);
                if (orderDetails == null)
                {
                    return NotFound();
                }

                ViewData["Order_Id"] = new SelectList(_context.Order, "Order_Id", "User_Id", orderDetails.Order_Id);
                ViewData["StProduct_Id"] = new SelectList(_context.StockProduct, "StProduct_Id", "StProduct_Name", orderDetails.StProduct_Id);

                return View(orderDetails);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // POST: OrderDetails/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, OrderDetails orderDetails)
        {
            try
            {
                if (id != orderDetails.Order_Id)
                {
                    return NotFound();
                }

                if (ModelState.IsValid)
                {
                    try
                    {
                        orderDetailsServices.CreateOrUpdateOrderDetails(orderDetails);
                    }
                    catch (DbUpdateConcurrencyException)
                    {
                        var existingOrderDetails = _context.OrderDetails.FindAsync(id);
                        if (existingOrderDetails == null)
                        {
                            return NotFound();
                        }
                        else
                        {
                            throw;
                        }
                    }

                    return RedirectToAction(nameof(Index));
                }

                ViewData["Order_Id"] = new SelectList(_context.Order, "Order_Id", "User_Id", orderDetails.Order_Id);
                ViewData["StProduct_Id"] = new SelectList(_context.StockProduct, "StProduct_Id", "StProduct_Name", orderDetails.StProduct_Id);

                return View(orderDetails);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }
    }
}
