﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace OrderSystemCompany.UI.Controllers
{
    // Apply authorization to the controller, allowing only users with the "Admin" role to access its actions
    [Authorize(Roles = "Admin")]
    public class AdminRulesController : Controller
    {
        // Action method that returns the "Index" view
        public IActionResult Index()
        {
            return View();
        }
    }
}
