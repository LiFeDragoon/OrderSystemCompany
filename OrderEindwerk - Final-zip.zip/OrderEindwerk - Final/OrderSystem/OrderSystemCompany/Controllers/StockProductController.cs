﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using OrderSystemCompany.DA;
using OrderSystemCompany.Objects;
using OrderSystemCompany.Services;

namespace OrderSystemCompany.UI.Controllers
{
    public class StockProductController : Controller
    {
        private readonly StockProductServices _stockProductServices = new StockProductServices();
        private readonly Repository _context = new Repository();

        // GET: StockProduct
        public IActionResult Index()
        {
            try
            {
                // Retrieve all stock products
                var list = _stockProductServices.GetStProduct();

                return View(list);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // GET: StockProduct/Details/5
        public IActionResult Details(int id)
        {
            try
            {
                // Retrieve the stock product by ID
                var stockProduct = _stockProductServices.GetStProductById(id);

                return View(stockProduct);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // GET: StockProduct/Create
        public IActionResult Create()
        {
            try
            {
                // Retrieve categories and suppliers to populate dropdown lists
                ViewData["Cat_Id"] = new SelectList(_context.Category, "Cat_Id", "Cat_Name");
                ViewData["Supplier_Id"] = new SelectList(_context.Supplier, "Supplier_Id", "Supplier_Name");

                return View();
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // POST: StockProduct/Create
        [HttpPost]
        public IActionResult Create(StockProduct stockProduct)
        {
            try
            {
                // Populate dropdown lists for categories and suppliers
                ViewData["Cat_Id"] = new SelectList(_context.Category, "Cat_Id", "Cat_Name", stockProduct.Cat_Id);
                ViewData["Supplier_Id"] = new SelectList(_context.Supplier, "Supplier_Id", "Supplier_Name", stockProduct.Supplier_Id);

                TryUpdateModelAsync(stockProduct);
                // Create or update the stock product
                _stockProductServices.CreateOrUpdateStProduct(stockProduct);

                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // GET: StockProduct/Edit/5
        public IActionResult Edit(int id)
        {
            try
            {
                // Retrieve the stock product by ID
                var stockProduct = _stockProductServices.GetStProductById(id);

                // Populate dropdown lists for categories and suppliers
                ViewData["Cat_Id"] = new SelectList(_context.Category, "Cat_Id", "Cat_Name", stockProduct.Cat_Id);
                ViewData["Supplier_Id"] = new SelectList(_context.Supplier, "Supplier_Id", "Supplier_Name", stockProduct.Supplier_Id);

                return View(stockProduct);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // POST: StockProduct/Edit/5
        [HttpPost]
        public IActionResult Edit(StockProduct stockProduct)
        {
            try
            {
                TryUpdateModelAsync(stockProduct);
                // Update the stock product
                _stockProductServices.CreateOrUpdateStProduct(stockProduct);

                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // GET: StockProduct/Delete/5
        public IActionResult Delete(int id)
        {
            try
            {
                // Retrieve the stock product to delete
                var productToDelete = _stockProductServices.GetStProductById(id);
                return View(productToDelete);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }

        // POST: StockProduct/Delete/5
        [HttpPost]
        public IActionResult Delete(int id, Order order)
        {
            try
            {
                _stockProductServices.DeleteStProduct(id);

                TempData["message"] = "Object has been deleted successfully.";

                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                Console.WriteLine($"An error occurred: {ex}");
                return StatusCode(500, "An error occurred while processing the request.");
            }
        }
    }
}
