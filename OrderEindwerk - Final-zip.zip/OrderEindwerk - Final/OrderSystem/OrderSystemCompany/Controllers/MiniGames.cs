﻿using Microsoft.AspNetCore.Mvc;

namespace OrderSystemCompany.UI.Controllers
{
    public class MiniGames : Controller
    {
        // GET: /MiniGames/Index
        public IActionResult Index()
        {
            // Render the Index view
            return View();
        }
    }
}
