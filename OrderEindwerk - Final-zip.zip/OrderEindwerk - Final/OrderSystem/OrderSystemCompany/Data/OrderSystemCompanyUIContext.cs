﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using OrderSystemCompany.UI.Models;

namespace OrderSystemCompany.UI.Data
{
    public class OrderSystemCompanyUIContext : DbContext
    {
        public OrderSystemCompanyUIContext (DbContextOptions<OrderSystemCompanyUIContext> options)
            : base(options)
        {
        }

        public DbSet<OrderSystemCompany.UI.Models.UserModels> UserModels { get; set; } = default!;
    }
}
