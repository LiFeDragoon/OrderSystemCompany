using LinqToDB;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using OrderSystemCompany.DA;
using OrderSystemCompany.Objects;
using OrderSystemCompany.Services;
using OrderSystemCompany.UI.AdminHelperOSC;

var builder = WebApplication.CreateBuilder(args);

// Get the connection string from the configuration
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection") ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");

// Configure the database context with the connection string
builder.Services.AddDbContext<Repository>(options =>
    options.UseSqlServer(connectionString));

// Add services to the container
builder.Services.AddDbContext<Repository>(options =>
    options.UseSqlServer(connectionString));

// Add default identity services for User management
builder.Services.AddDefaultIdentity<User>(options => options.SignIn.RequireConfirmedAccount = true)
    .AddRoles<IdentityRole>()
    .AddEntityFrameworkStores<Repository>();

// Add the required services for dependency injection
builder.Services.AddTransient<OrderDetailsServices>();
builder.Services.AddTransient<StockProductServices>();
builder.Services.AddTransient<OrderServices>();
builder.Services.AddTransient<SupplierServices>();
builder.Services.AddTransient<UserServices>();
builder.Services.AddTransient<MessagesServices>();
builder.Services.AddTransient<CustomerFileServices>();
builder.Services.AddTransient<StatusMessagesServices>();
builder.Services.AddTransient<CategoryServices>();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    // Configure error handling for non-development environments
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseAuthorization();

// Configure routing for MVC controllers
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.MapRazorPages();

// Seed the database with roles and admin user
using (var scope = app.Services.CreateScope())
{
    await SeedDataBaseHelper.SeedRolesAndAdmin(scope.ServiceProvider);
}

app.Run();
