﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using OrderSystemCompany.Objects;

// Namespace where the Repository class is defined
namespace OrderSystemCompany.DA
{
    // Repository class derived from IdentityDbContext, which provides functionality for managing user authentication and authorization
    public class Repository : IdentityDbContext
    {
        // DbSet representing the "OrderDetails" entity in the database
        public DbSet<OrderDetails> OrderDetails { get; set; }

        // DbSet representing the "StockProduct" entity in the database
        public DbSet<StockProduct> StockProduct { get; set; }

        // DbSet representing the "Order" entity in the database
        public DbSet<Order> Order { get; set; }

        // DbSet representing the "Supplier" entity in the database
        public DbSet<Supplier> Supplier { get; set; }

        // DbSet representing the "Category" entity in the database
        public DbSet<Category> Category { get; set; }

        // DbSet representing the "Messages" entity in the database
        public DbSet<Messages> Messages { get; set; }

        // DbSet representing the "User" entity in the database
        public DbSet<User> Users { get; set; }

        // DbSet representing the "CustomerFile" entity in the database
        public DbSet<CustomerFile> CustomerFile { get; set; }

        // DbSet representing the "StatusMessages" entity in the database
        public DbSet<StatusMessages> StatusMessages { get; set; }

        // Default constructor for the Repository class
        public Repository() { }

        // Constructor that accepts DbContextOptions as a parameter and passes it to the base class constructor
        public Repository(DbContextOptions<Repository> options) : base(options) { }

        // Override method to configure the DbContext options
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);

            // Check if the options builder is not already configured
            if (!optionsBuilder.IsConfigured)
            {
                // Configuring the options to use SQL Server with a specific connection string
                optionsBuilder.UseSqlServer("Data Source=(LocalDB)\\MSSQLLocalDB;Initial Catalog=aspnet-OrderSystemCompany-6f554b36-4bb5-40f1-b5af-52dcf24e008b;Integrated Security=True;Trust Server Certificate=True");
            }
        }
    }
}
