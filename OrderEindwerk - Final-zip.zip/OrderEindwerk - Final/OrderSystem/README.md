to use application run the script into SQL

IF it does not work try updating the data base into terminal using the code
cd.OrderSystemCompany.DA

IF no migration present in the DA, input code
dotnet ef migrations add CreateIdentitySchema

If migration is present use the code
dotnet ef database update


If it still dont work, delete migrations, delete connection and database and run above.

make sure your database server is the common (LocalDB)\MSSQLLocalDB

RUN the OrderSystemCompany.UI to run the web application
RUN the OrderSystemCompanyAPI.Webb to run api in swagger

for more details on questions send email to:
	Lieven.delameillieure@gmail.com
	use subject: OrderSystemCompany


admin login:

admin@gmail.com
Testing*123


om de database te laten werken moet je de volgende stappen ondernemen:

- open sql
- connect to server ->   (LocalDB)\MSSQLLocalDB
- rechtermuisklik op databases
- restore database
- SELECT device
- open de 3puntjes vak [...]
- select add
- ga naar de folder waar de BAK backupfile staat
- selecteer deze en druk 2 keer op oké
(dan zou deze moeten geconecteerd zijn met de bestaande applicatie)

