﻿using Microsoft.IdentityModel.Tokens;
using OrderSystemCompany.Objects;
using OrderSystemCompany.UI.Dto;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace OrderSystemCompany.UI.Helper
{
    public class JwtHelper
    {
        private const int EXPIRATION_MINUTES = 1; // Expiration time for the token in minutes

        private readonly IConfiguration _configuration; // Configuration object to access app settings

        public JwtHelper(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public AuthResDto CreateToken(User user)
        {
            var expiration = DateTime.UtcNow.AddMinutes(EXPIRATION_MINUTES); // Token expiration time

            var token = CreateJwtToken(
                CreateClaims(user),
                CreateSigningCredentials(),
                expiration
            );

            var tokenHandler = new JwtSecurityTokenHandler();

            return new AuthResDto
            {
                Token = tokenHandler.WriteToken(token), // Serialized token
                Expiration = expiration // Expiration date/time of the token
            };
        }

        private JwtSecurityToken CreateJwtToken(Claim[] claims, SigningCredentials credentials, DateTime expiration) =>
            new JwtSecurityToken(
                _configuration["Jwt:Issuer"], // Issuer of the token
                _configuration["Jwt:Audience"], // Audience of the token
                claims,
                expires: expiration,
                signingCredentials: credentials
            );

        private Claim[] CreateClaims(User user) =>
            new[] {
                new Claim(JwtRegisteredClaimNames.Sub, _configuration["Jwt:Subject"]), // Subject claim
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()), // JWT ID claim
                new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString()), // Issued At claim
                new Claim(ClaimTypes.NameIdentifier, user.Id), // User ID claim
                new Claim(ClaimTypes.Name, user.UserName), // User name claim
                new Claim(ClaimTypes.Email, user.Email) // User email claim
            };

        private SigningCredentials CreateSigningCredentials() =>
            new SigningCredentials(
                new SymmetricSecurityKey(
                    Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]) // Secret key for signing the token
                ),
                SecurityAlgorithms.HmacSha256
            );
    }
}
