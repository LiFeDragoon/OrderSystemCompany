﻿using Microsoft.AspNetCore.Mvc;
using OrderSystemCompany.Services;

namespace OrderSystemCompanyAPI.Webb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SupplierAPIController : ControllerBase
    {
        private readonly ISupplierServices _supplierServices;

        public SupplierAPIController(ISupplierServices supplierServices)
        {
            _supplierServices = supplierServices;
        }

        // GET: api/SupplierAPI
        [HttpGet]
        public IActionResult Get()
        {
            // Retrieve the list of suppliers from the supplier services
            var list = _supplierServices.GetSupplier();

            // Return the list of suppliers as a response
            return Ok(list);
        }

        // POST: api/SupplierAPI
        [HttpPost]
        public IActionResult Post([FromBody] OrderSystemCompany.Objects.Supplier supplier)
        {
            try
            {
                // Create or update the supplier using the supplier services
                _supplierServices.CreateOrUpdateSupplier(supplier);

                // Return a success response
                return Ok();
            }
            catch (System.Exception ex)
            {
                // Handle the exception and return an appropriate response
                // For example, you can return a server error status code (500) with an error message
                return StatusCode(500, "An error occurred while saving the supplier.");
            }
        }

        // PUT: api/SupplierAPI/{id}
        [HttpPut("{id}")]
        public IActionResult Put([FromBody] OrderSystemCompany.Objects.Supplier supplier)
        {
            try
            {
                // Create or update the supplier using the supplier services
                _supplierServices.CreateOrUpdateSupplier(supplier);

                // Return a success response
                return Ok();
            }
            catch (System.Exception ex)
            {
                // Handle the exception and return an appropriate response
                // For example, you can return a server error status code (500) with an error message
                return StatusCode(500, "An error occurred while saving the supplier.");
            }
        }

        // DELETE: api/SupplierAPI/{id}
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                // Delete the specified supplier using the supplier services
                _supplierServices.DeleteSupplier(id);

                // Return a success response
                return Ok();
            }
            catch (System.Exception ex)
            {
                // Handle the exception and return an appropriate response
                // For example, you can return a server error status code (500) with an error message
                return StatusCode(500, "An error occurred while deleting the supplier.");
            }
        }
    }
}
