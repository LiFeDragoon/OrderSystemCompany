﻿using Microsoft.AspNetCore.Mvc;
using OrderSystemCompany.Objects;
using OrderSystemCompany.Services;
using OrderSystemCompanyAPI.Webb.Dto;

namespace OrderSystemCompanyAPI.Webb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderAPIController : ControllerBase
    {
        private readonly IOrderServices _orderServices;
        private readonly IStockProductServices _stockProductServices;
        private readonly IOrderDetailsServices _orderDetailsServices;

        public OrderAPIController(IOrderServices orderServices, IStockProductServices stockProductServices, IOrderDetailsServices orderDetailsServices)
        {
            _orderServices = orderServices;
            _stockProductServices = stockProductServices;
            _orderDetailsServices = orderDetailsServices;
        }

        // GET api/orderapi
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                // Retrieve the list of orders from the order services
                var list = _orderServices.GetOrder();

                // Return the list of orders as a response
                return Ok(list);
            }
            catch (Exception ex)
            {
                // Handle exceptions and return an appropriate response
                // For example, you can return a server error status code (500) with an error message
                return StatusCode(500, "An error occurred while retrieving orders.");
            }
        }

        // POST api/orderapi
        [HttpPost]
        public ActionResult Create(OrderDto orderDto)
        {
            try
            {
                // Create a new Order object and populate it with values from the OrderDto
                var order = new Order();
                order.Order_Date = orderDto.Order_Date.Value;
                order.Order_ShipDate = orderDto.Order_ShipDate.Value;
                order.Order_Shipped = orderDto.Order_Shipped.Value;
                order.Order_PaymentReceived = orderDto.Order_PaymentReceived.Value;
                order.User_Id = orderDto.User_Id;
                order.OrderDetails = new List<OrderDetails>();

                // Create or update the order using the order services
                _orderServices.CreateOrUpdateOrder(order);

                // Create and associate OrderDetails objects with the order
                foreach (var item in orderDto.OrderDetails)
                {
                    var orderDetails = new OrderDetails();
                    orderDetails.StProduct_Id = item.StProduct_Id;
                    orderDetails.Order_Id = order.Order_Id;
                    orderDetails.Quantity = item.Quantity;
                    order.OrderDetails.Add(orderDetails);
                }

                // Create or update the order details using the order details services
                _orderDetailsServices.CreateOrUpdateOrderDetails(order.OrderDetails.FirstOrDefault());

                // Return the created order as a response
                return Ok(order);
            }
            catch (Exception ex)
            {
                // Handle exceptions and return an appropriate response
                // For example, you can return a server error status code (500) with an error message
                return StatusCode(500, "An error occurred while creating the order.");
            }
        }

        // DELETE api/orderapi/{id}
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                // Delete the order with the specified id using the order services
                _orderServices.DeleteOrder(id);

                // Return a success response
                return Ok();
            }
            catch (Exception ex)
            {
                // Handle exceptions and return an appropriate response
                // For example, you can return a server error status code (500) with an error message
                return StatusCode(500, "An error occurred while deleting the order.");
            }
        }
    }
}
