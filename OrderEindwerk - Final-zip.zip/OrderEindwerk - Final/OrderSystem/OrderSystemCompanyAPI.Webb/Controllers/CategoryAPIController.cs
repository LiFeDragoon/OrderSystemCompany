﻿using Microsoft.AspNetCore.Mvc;
using OrderSystemCompany.Objects;
using OrderSystemCompany.Services;

namespace OrderSystemCompanyAPI.Webb.Controllers
{
    /* [Authorize]*/ // Users need to be authenticated to access this controller
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryAPIController : ControllerBase
    {
        private readonly ICategoryServices _categoryServices;
        private readonly ILogger<CategoryAPIController> _logger;

        public CategoryAPIController(ICategoryServices categoryServices, ILogger<CategoryAPIController> logger)
        {
            _categoryServices = categoryServices;
            _logger = logger;
        }

        // GET api/categories
        [HttpGet]
        public IActionResult Get()
        {
            // Retrieve the list of categories from the category services
            var list = _categoryServices.GetCategory();

            // Return the list of categories as a response
            return Ok(list);
        }

        // POST api/categories
        [HttpPost]
        public IActionResult Post(Category category)
        {
            // Create or update the category using the category services
            _categoryServices.CreateOrUpdateCategory(category);

            // Return a success response
            return Ok();
        }

        // PUT api/categories
        [HttpPut]
        public IActionResult Put(Category category)
        {
            try
            {
                // Create or update the category using the category services
                _categoryServices.CreateOrUpdateCategory(category);

                // Return a success response
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while updating the category.");
                var statusCode = GetStatusCodeForException(ex);
                var errorMessage = GetErrorMessageForException(ex);

                // Return an error response with the appropriate status code and error message
                return StatusCode(statusCode, errorMessage);
            }
        }

        // DELETE api/categories/{id}
        [HttpDelete]
        [Route("{id}")]
        public IActionResult Delete(int id)
        {
            // Delete the category with the specified id using the category services
            _categoryServices.DeleteCategory(id);

            if (id == 0)
            {
                return StatusCode(409); // Conflict
            }
            return Ok(id);
        }

        private int GetStatusCodeForException(Exception ex)
        {
            // Map specific exceptions to appropriate status codes
            if (ex is InvalidOperationException)
            {
                return 400; // Bad Request
            }
            else if (ex is UnauthorizedAccessException)
            {
                return 401; // Unauthorized
            }
            else if (ex is SomeOtherException)
            {
                return 500; // Internal Server Error
            }

            return 500; // Default to Internal Server Error
        }

        private string GetErrorMessageForException(Exception ex)
        {
            // Customize error messages based on the exception type
            if (ex is InvalidOperationException)
            {
                return "Invalid operation.";
            }
            else if (ex is UnauthorizedAccessException)
            {
                return "Unauthorized access.";
            }
            else if (ex is SomeOtherException)
            {
                return "An error occurred while processing the request.";
            }

            return "An error occurred.";
        }
    }
}
