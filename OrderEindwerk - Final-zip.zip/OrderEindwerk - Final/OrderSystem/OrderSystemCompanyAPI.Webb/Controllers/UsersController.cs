﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using OrderSystemCompany.Objects;
using OrderSystemCompany.UI.Dto;
using OrderSystemCompany.UI.Helper;

namespace CarAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly UserManager<User> _userManager;
        private readonly JwtHelper _jwtHelper;

        public UsersController(UserManager<User> userManager, JwtHelper jwtHelper)
        {
            _userManager = userManager;
            _jwtHelper = jwtHelper;
        }

        // POST: api/Users/create
        [HttpPost("create")]
        public async Task<ActionResult<UserDto>> PostUser(UserDto user)
        {
            if (!ModelState.IsValid)
            {
                // Return a bad request response with the invalid model state
                return BadRequest(ModelState);
            }

            // Create a new User entity and store it in the database using the UserManager
            var result = await _userManager.CreateAsync(
                new User() { UserName = user.UserName, Email = user.Email },
                user.Password
            );

            if (!result.Succeeded)
            {
                // Return a bad request response with the errors from the identity operation
                return BadRequest(result.Errors);
            }

            user.Password = null;
            // Return a created response with the newly created user as the payload
            return CreatedAtAction("GetUser", new { username = user.UserName }, user);
        }

        // GET: api/Users/username
        [HttpGet("{username}")]
        public async Task<ActionResult<UserDto>> GetUser(string username)
        {
            // Find the User entity with the specified username using the UserManager
            User user = await _userManager.FindByNameAsync(username);

            if (user == null)
            {
                // Return a not found response if the user is not found
                return NotFound();
            }

            // Return a user DTO with the selected properties
            return new UserDto
            {
                UserName = user.UserName,
                Email = user.Email
            };
        }
    }
}
