﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OrderSystemCompany.Objects;
using OrderSystemCompany.Services;

namespace OrderSystemCompanyAPI.Webb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StockProductAPIController : ControllerBase
    {
        private readonly IStockProductServices _StockProductServices;

        public StockProductAPIController(IStockProductServices stockProductServices)
        {
            _StockProductServices = stockProductServices;
        }

        // GET: api/StockProductAPI
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                // Retrieve the list of stock products from the stock product services
                var list = _StockProductServices.GetStProduct();

                // Return the list of stock products as a response
                return Ok(list);
            }
            catch (Exception ex)
            {
                // Handle exceptions and return an appropriate response
                // For example, you can return a server error status code (500) with an error message
                return StatusCode(500, "An error occurred while retrieving stock products.");
            }
        }

        // POST: api/StockProductAPI
        [HttpPost]
        public IActionResult Post([FromBody] StockProduct stockProduct)
        {
            try
            {
                // Set the properties of the stock product based on the provided data
                stockProduct.StProduct_Name = stockProduct.StProduct_Name;
                stockProduct.StProduct_Description = stockProduct.StProduct_Description;
                stockProduct.StProduct_Price = stockProduct.StProduct_Price;
                stockProduct.StProduct_UnitInStock = stockProduct.StProduct_UnitInStock;
                stockProduct.Supplier_Id = stockProduct.Supplier_Id;
                stockProduct.Cat_Id = stockProduct.Cat_Id;

                // Create or update the stock product using the stock product services
                _StockProductServices.CreateOrUpdateStProduct(stockProduct);

                // Return a success response
                return Ok();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                // Handle concurrency exception and return an appropriate response
                // For example, you can return a conflict status code (409) with an error message
                return StatusCode(409, "Concurrency error occurred while saving the stock product.");
            }
            catch (Exception ex)
            {
                // Handle other exceptions and return an appropriate response
                // For example, you can return a server error status code (500) with an error message
                return StatusCode(500, "An error occurred while saving the stock product.");
            }
        }

        // PUT: api/StockProductAPI
        [HttpPut]
        public IActionResult Put(StockProduct stockProduct)
        {
            try
            {
                // Create or update the stock product using the stock product services
                _StockProductServices.CreateOrUpdateStProduct(stockProduct);

                // Return a success response
                return Ok();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                // Handle concurrency exception and return an appropriate response
                // For example, you can return a conflict status code (409) with an error message
                return StatusCode(409, "Concurrency error occurred while saving the stock product.");
            }
            catch (Exception ex)
            {
                // Handle other exceptions and return an appropriate response
                // For example, you can return a server error status code (500) with an error message
                return StatusCode(500, "An error occurred while saving the stock product.");
            }
        }

        // DELETE: api/StockProductAPI/{id}
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                // Delete the specified stock product using the stock product services
                _StockProductServices.DeleteStProduct(id);

                // Return a success response
                return Ok();
            }
            catch (Exception ex)
            {
                // Handle exceptions and return an appropriate response
                // For example, you can return a server error status code (500) with an error message
                return StatusCode(500, "An error occurred while deleting the stock product.");
            }
        }
    }
}
