﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OrderSystemCompany.Objects;
using OrderSystemCompany.Services;

namespace OrderSystemCompanyAPI.Webb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MessageAPIController : ControllerBase
    {
        private readonly IMessagesServices _messageServices;

        public MessageAPIController(IMessagesServices messageServices)
        {
            _messageServices = messageServices;
        }

        // GET api/messageapi
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                // Retrieve the list of messages from the message services
                var list = _messageServices.GetMessage();

                // Return the list of messages as a response
                return Ok(list);
            }
            catch (Exception ex)
            {
                // Handle exceptions and return an appropriate response
                // For example, you can return a server error status code (500) with an error message
                return StatusCode(500, "An error occurred while retrieving messages.");
            }
        }

        // POST api/messageapi
        [HttpPost]
        public IActionResult Post(Messages messages)
        {
            try
            {
                // Set the Message_Description based on the provided value
                messages.Message_Description = messages.Message_Description;

                // Create or update the message using the message services
                _messageServices.CreateOrUpdateMessage(messages);

                // Return a success response
                return Ok();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                // Handle concurrency exception and return a conflict status code (409) with an error message
                return StatusCode(409, "Concurrency error occurred while saving the message.");
            }
            catch (Exception ex)
            {
                // Handle other exceptions and return a server error status code (500) with an error message
                return StatusCode(500, "An error occurred while saving the message.");
            }
        }

        // PUT api/messageapi/{id}
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] Messages messages)
        {
            try
            {
                // Set the Message_Id based on the provided ID
                messages.Message_Id = id;

                // Create or update the message using the message services
                _messageServices.CreateOrUpdateMessage(messages);

                // Return a success response
                return Ok();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                // Handle concurrency exception and return a conflict status code (409) with an error message
                return StatusCode(409, "Concurrency error occurred while saving the message.");
            }
            catch (Exception ex)
            {
                // Handle other exceptions and return a server error status code (500) with an error message
                return StatusCode(500, "An error occurred while saving the message.");
            }
        }

        // DELETE api/messageapi/{id}
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                // Delete the message with the specified id using the message services
                _messageServices.DeleteMessage(id);

                // Return a success response
                return Ok();
            }
            catch (Exception ex)
            {
                // Handle exceptions and return an appropriate response
                // For example, you can return a server error status code (500) with an error message
                return StatusCode(500, "An error occurred while deleting the message.");
            }
        }
    }
}
