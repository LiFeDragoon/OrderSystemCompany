﻿using Microsoft.AspNetCore.Mvc;
using OrderSystemCompany.Objects;
using OrderSystemCompany.Services;

namespace OrderSystemCompanyAPI.Webb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderDetailsAPIController : ControllerBase
    {
        private readonly IOrderDetailsServices _orderDetailsServices;
        private readonly IStockProductServices _stockProductServices;

        public OrderDetailsAPIController(IOrderDetailsServices orderDetailsServices, IStockProductServices stockProductServices)
        {
            _orderDetailsServices = orderDetailsServices;
            _stockProductServices = stockProductServices;
        }

        // GET: api/OrderDetailsAPI
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                // Retrieve the list of order details from the order details services
                var list = _orderDetailsServices.GetOrderDetails();

                // Return the list of order details as a response
                return Ok(list);
            }
            catch (Exception ex)
            {
                // Handle exceptions and return an appropriate response
                // For example, you can return a server error status code (500) with an error message
                return StatusCode(500, "An error occurred while retrieving order details.");
            }
        }

        // POST: api/OrderDetailsAPI/DeleteOrderDetails
        [HttpDelete]
        [Route("DeleteOrderDetails")]
        public IActionResult DeleteOrderDetails([FromBody] OrderDetails orderDetails)
        {
            try
            {
                // Delete the specified order details using the order details services
                _orderDetailsServices.DeleteOrderDetails(orderDetails);

                // Return a success response
                return Ok();
            }
            catch (Exception ex)
            {
                // Handle exceptions and return an appropriate response
                // For example, you can return a server error status code (500) with an error message
                return StatusCode(500, "An error occurred while deleting the order details.");
            }
        }
    }
}
