﻿using System.Runtime.Serialization;

namespace OrderSystemCompanyAPI.Webb.Controllers
{
    [Serializable]
    internal class SomeOtherException : Exception
    {
        public SomeOtherException()
        {
        }

        public SomeOtherException(string? message) : base(message)
        {
        }

        public SomeOtherException(string? message, Exception? innerException) : base(message, innerException)
        {
        }

        protected SomeOtherException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}