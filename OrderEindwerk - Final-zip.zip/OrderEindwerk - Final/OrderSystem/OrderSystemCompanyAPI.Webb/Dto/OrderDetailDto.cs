﻿namespace OrderSystemCompanyAPI.Webb.Dto
{
    public class OrderDetailDto
    {
        public double? Quantity { get; set; }  // Represents the quantity of a product in an order detail
        public int? StProduct_Id { get; set; }  // Represents the ID of a stock product associated with the order detail
    }
}
