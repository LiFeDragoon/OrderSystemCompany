﻿using System.ComponentModel.DataAnnotations;

namespace OrderSystemCompany.UI.Dto
{
    public class OrderSystemDto
    {
        [Required(ErrorMessage = "Please provide a name")]
        public int Name { get; set; }  // Represents the name of the order system

        public string Description { get; set; }  // Represents the description of the order system
    }
}
