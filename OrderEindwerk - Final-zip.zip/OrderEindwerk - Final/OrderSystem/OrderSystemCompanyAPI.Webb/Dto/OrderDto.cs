﻿using System.ComponentModel.DataAnnotations;

namespace OrderSystemCompanyAPI.Webb.Dto
{
    public class OrderDto
    {
        [Required(ErrorMessage = "Please provide a Product name")]
        public DateTime? Order_Date { get; set; }  // Represents the order date

        public DateTime? Order_ShipDate { get; set; }  // Represents the shipping date of the order
        public bool? Order_Shipped { get; set; }  // Indicates whether the order has been shipped or not
        public bool? Order_PaymentReceived { get; set; }  // Indicates whether the payment for the order has been received or not
        public string? User_Id { get; set; }  // Represents the ID of the user associated with the order

        public List<OrderDetailDto> OrderDetails { get; set; }  // Represents the list of order details associated with the order
    }
}
