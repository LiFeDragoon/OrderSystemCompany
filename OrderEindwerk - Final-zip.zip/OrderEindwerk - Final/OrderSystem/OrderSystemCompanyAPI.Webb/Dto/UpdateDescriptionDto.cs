﻿using System.ComponentModel.DataAnnotations;

namespace OrderSystemCompany.UI.Dto
{

    public class UpdateDescriptionDto //DTO = data transfer object
    {
        [Required(ErrorMessage = "Please provide a description")]
        public string Description { get; set; }
    }
}
