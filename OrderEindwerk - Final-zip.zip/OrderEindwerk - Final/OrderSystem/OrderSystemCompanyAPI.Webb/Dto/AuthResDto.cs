﻿namespace OrderSystemCompany.UI.Dto
{
    public class AuthResDto
    {
        public string Token { get; set; }  // Represents the authentication token
        public DateTime Expiration { get; set; }  // Represents the expiration date of the token
    }
}
