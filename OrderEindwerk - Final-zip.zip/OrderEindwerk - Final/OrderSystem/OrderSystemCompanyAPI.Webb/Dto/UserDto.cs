﻿using System.ComponentModel.DataAnnotations;

namespace OrderSystemCompany.UI.Dto
{
    public class UserDto
    {
        [Required]
        public string UserName { get; set; }  // Represents the username of the user

        [Required]
        public string Password { get; set; }  // Represents the password of the user

        [Required]
        public string Email { get; set; }  // Represents the email address of the user
    }
}
