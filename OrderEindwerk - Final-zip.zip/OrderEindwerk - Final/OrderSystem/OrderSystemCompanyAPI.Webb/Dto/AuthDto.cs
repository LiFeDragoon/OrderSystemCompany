﻿using System.ComponentModel.DataAnnotations;

namespace OrderSystemCompany.UI.Dto
{
    public class AuthDto
    {
        [Required]
        public string UserName { get; set; }  // Represents the username for authentication

        [Required]
        public string Password { get; set; }  // Represents the password for authentication
    }
}
