﻿using OrderSystemCompany.DA;
using OrderSystemCompany.Objects;

namespace OrderSystemCompany.Services
{
    public interface ICategoryServices
    {
        List<Category> GetCategory(); // Retrieves a list of categories
        List<int> GetCategoryById(); // Retrieves a list of category IDs
        void CreateOrUpdateCategory(Category category); // Creates or updates a category
        void DeleteCategory(int id); // Deletes a category by ID
        void CreateCategory(Category category); // Creates a new category
    }

    public class CategoryServices : ICategoryServices
    {
        public List<Category> GetCategory()
        {
            using (var repo = new Repository())
            {
                return repo.Category.ToList(); // Retrieve all categories from the repository
            }
        }

        public List<int> GetCategoryById()
        {
            using (var repo = new Repository())
            {
                var categoryIDs = repo.Category.Select(category => category.Cat_Id); // Retrieve only the category IDs from the repository
                return categoryIDs.ToList();
            }
        }

        public void CreateOrUpdateCategory(Category category)
        {
            using (var repo = new Repository())
            {
                if (category.Cat_Id == 0) // If the category ID is 0, it means it's a new category that needs to be created
                {
                    repo.Category.Add(category); // Add the new category to the repository
                }
                else // If the category ID is not 0, it means it's an existing category that needs to be updated
                {
                    repo.Attach(category);
                    var e = repo.ChangeTracker.Entries().FirstOrDefault(e => e.Entity == category);
                    e.State = Microsoft.EntityFrameworkCore.EntityState.Modified; // Mark the category as modified in the repository
                }
                repo.SaveChanges(); // Save the changes to the repository
            }
        }

        public void DeleteCategory(int id)
        {
            using (var repo = new Repository())
            {
                var toDelete = repo.Category.FirstOrDefault(category => category.Cat_Id == id); // Find the category to delete by its ID
                if (toDelete != null)
                {
                    repo.Category.Remove(toDelete); // Remove the category from the repository
                    repo.SaveChanges(); // Save the changes to the repository
                }
            }
        }

        public void CreateCategory(Category category)
        {
            using (var repo = new Repository())
            {
                repo.Category.Add(category); // Add the new category to the repository
                repo.SaveChanges(); // Save the changes to the repository
            }
        }
    }
}
