﻿using Microsoft.EntityFrameworkCore;
using OrderSystemCompany.DA;
using OrderSystemCompany.Objects;

namespace OrderSystemCompany.Services
{
    public interface ISupplierServices
    {
        List<Supplier> GetSupplier();
        List<int> GetSuppliersById(int id);
        bool DeleteSupplier(int id);
        void CreateOrUpdateSupplier(Supplier supplier);
    }

    public class SupplierServices : ISupplierServices
    {
        // Retrieve all suppliers
        public List<Supplier> GetSupplier()
        {
            using (var repo = new Repository())
            {
                return repo.Supplier.ToList();
            }
        }

        // Get the IDs of suppliers and return them as a list
        public List<int> GetSuppliersById(int id)
        {
            using (var repo = new Repository())
            {
                var supplierIDs = repo.Supplier.Select(supplier => supplier.Supplier_Id);
                return supplierIDs.ToList();
            }
        }

        // Create or update a supplier
        public void CreateOrUpdateSupplier(Supplier supplier)
        {
            using (var repo = new Repository())
            {
                if (supplier.Supplier_Id == 0)
                {
                    // Create a new supplier object with the provided information
                    var newSupplier = new Supplier
                    {
                        Supplier_Name = supplier.Supplier_Name,
                        Supplier_Address = supplier.Supplier_Address,
                        Supplier_Phone = supplier.Supplier_Phone,
                        Supplier_Email = supplier.Supplier_Email
                    };

                    repo.Supplier.Add(newSupplier); // Add the new supplier to the repository
                }
                else
                {
                    repo.Attach(supplier);
                    var e = repo.ChangeTracker.Entries().FirstOrDefault(e => e.Entity == supplier);
                    e.State = EntityState.Modified; // Mark the existing supplier as modified in the repository
                }

                repo.SaveChanges(); // Save the changes to the repository
            }
        }

        // Delete a supplier by its ID
        public bool DeleteSupplier(int id)
        {
            using (var repo = new Repository())
            {
                var supplier = repo.Supplier.FirstOrDefault(c => c.Supplier_Id == id);
                if (supplier != null)
                {
                    repo.Supplier.Remove(supplier); // Remove the supplier from the repository
                    repo.SaveChanges(); // Save the changes to the repository
                    return true;
                }

                return false;
            }
        }
    }
}
