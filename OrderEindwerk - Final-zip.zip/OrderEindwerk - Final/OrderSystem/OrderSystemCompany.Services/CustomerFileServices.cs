﻿using Microsoft.EntityFrameworkCore;
using OrderSystemCompany.DA;
using OrderSystemCompany.Objects;

namespace OrderSystemCompany.Services
{
    public interface ICustomerFileServices
    {
        List<CustomerFile> GetCustomerFile(); // Retrieves a list of customer files
        CustomerFile GetCustomerFileById(int id); // Retrieves a customer file by ID
        bool DeleteCustomerFile(int id); // Deletes a customer file by ID
        void CreateOrUpdateCustomerFile(CustomerFile customerFile); // Creates or updates a customer file
    }

    public class CustomerFileServices : ICustomerFileServices
    {
        public List<CustomerFile> GetCustomerFile()
        {
            using (var repo = new Repository())
            {
                return repo.CustomerFile.ToList(); // Retrieve all customer files from the repository
            }
        }

        public CustomerFile GetCustomerFileById(int id)
        {
            using (var repo = new Repository())
            {
                return repo.CustomerFile.FirstOrDefault(cf => cf.CustomerFile_Id == id); // Retrieve a customer file by its ID from the repository
            }
        }

        public void CreateOrUpdateCustomerFile(CustomerFile customerFile)
        {
            using (var repo = new Repository())
            {
                if (customerFile.CustomerFile_Id == 0) // If the customer file ID is 0, it means it's a new customer file that needs to be created
                {
                    var newCustomerFile = new CustomerFile
                    {
                        CustomerFile_Name = customerFile.CustomerFile_Name,
                        CustomerFile_Address = customerFile.CustomerFile_Address,
                        CustomerFile_Phone = customerFile.CustomerFile_Phone,
                        CustomerFile_Email = customerFile.CustomerFile_Email,
                        CustomerFile_Country = customerFile.CustomerFile_Country,
                        CustomerFile_City = customerFile.CustomerFile_City,
                        CustomerFile_PostalCode = customerFile.CustomerFile_PostalCode
                    };

                    repo.CustomerFile.Add(newCustomerFile); // Add the new customer file to the repository
                }
                else // If the customer file ID is not 0, it means it's an existing customer file that needs to be updated
                {
                    repo.Update(customerFile); // Update the customer file in the repository
                }

                repo.SaveChanges(); // Save the changes to the repository
            }
        }

        public bool DeleteCustomerFile(int id)
        {
            using (var repo = new Repository())
            {
                var customerFile = repo.CustomerFile.FirstOrDefault(c => c.CustomerFile_Id == id); // Find the customer file to delete by its ID
                if (customerFile != null)
                {
                    repo.CustomerFile.Remove(customerFile); // Remove the customer file from the repository
                    repo.SaveChanges(); // Save the changes to the repository
                    return true;
                }

                return false; // Return false if the customer file with the specified ID was not found
            }
        }

        public void EditCustomerFile(CustomerFile customerFile)
        {
            using (var repo = new Repository())
            {
                repo.Attach(customerFile);
                var e = repo.ChangeTracker.Entries().FirstOrDefault(e => e.Entity == customerFile);
                e.State = EntityState.Modified; // Mark the customer file as modified in the repository
                repo.SaveChanges(); // Save the changes to the repository
            }
        }
    }
}
