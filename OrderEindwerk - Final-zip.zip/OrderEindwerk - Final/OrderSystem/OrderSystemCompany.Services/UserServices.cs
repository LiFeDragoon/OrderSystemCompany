﻿using OrderSystemCompany.DA;
using OrderSystemCompany.Objects;

namespace OrderSystemCompany.Services
{
    public interface IUserServices
    {
        void CreateUser(User user);
        List<User> GetUsers();
        User GetUserById(string id);
        void UpdateUser(User user);
        void DeleteUser(string id);
    }

    public class UserServices : IUserServices
    {
        // Create a new user
        public void CreateUser(User user)
        {
            using (var repo = new Repository())
            {
                repo.Users.Add(user); // Add the user to the repository
                repo.SaveChanges(); // Save the changes to the repository
            }
        }

        // Retrieve all users
        public List<User> GetUsers()
        {
            using (var repo = new Repository())
            {
                return repo.Users.ToList(); // Return a list of all users from the repository
            }
        }

        // Get a user by their ID
        public User GetUserById(string id)
        {
            using (var repo = new Repository())
            {
                return (User)(repo.Users.FirstOrDefault(user => user.Id == id) ?? new User());
                // Return the user with the specified ID if found, otherwise return a new User object
            }
        }

        // Update a user
        public void UpdateUser(User user)
        {
            using (var repo = new Repository())
            {
                repo.Users.Attach(user); // Attach the user object to the repository
                var e = repo.ChangeTracker.Entries().FirstOrDefault(user => user.Entity == user);
                e.State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                // Mark the user as modified in the repository
                repo.SaveChanges(); // Save the changes to the repository
            }
        }

        // Delete a user by their ID
        public void DeleteUser(string id)
        {
            using (var repo = new Repository())
            {
                var toDelete = repo.Users.FirstOrDefault(user => user.Id == id);
                // Find the user with the specified ID in the repository
                if (toDelete != null)
                {
                    repo.Users.Remove(toDelete); // Remove the user from the repository
                    repo.SaveChanges(); // Save the changes to the repository
                }
            }
        }
    }
}
