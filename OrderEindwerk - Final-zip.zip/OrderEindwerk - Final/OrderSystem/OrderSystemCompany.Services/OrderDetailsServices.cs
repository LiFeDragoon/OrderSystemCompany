﻿using Microsoft.EntityFrameworkCore;
using OrderSystemCompany.DA;
using OrderSystemCompany.Objects;
using System.Net.Mail;

namespace OrderSystemCompany.Services
{
    public interface IOrderDetailsServices
    {
        List<OrderDetails> GetOrderDetails(); // Retrieves a list of order details
        OrderDetails GetOrderDetailsById(int id); // Retrieves an order detail by its ID
        void CreateOrUpdateOrderDetails(OrderDetails orderDetails); // Creates or updates an order detail
        void DeleteOrderDetails(OrderDetails orderDetails); // Deletes an order detail
    }

    public class OrderDetailsServices : IOrderDetailsServices
    {
        public List<OrderDetails> GetOrderDetails()
        {
            using (var repo = new Repository())
            {
                return repo.OrderDetails
                    .Include(o => o.Order)
                    .Include(o => o.StockProduct)
                    .Include(o => o.Order.User)
                    .Include(o => o.CustomerFile)
                    .ToList(); // Retrieve all order details from the repository, including related entities (Order, StockProduct, User, and CustomerFile)
            }
        }

        public OrderDetails GetOrderDetailsById(int id)
        {
            using (var repo = new Repository())
            {
                return repo.OrderDetails
                    .Include(o => o.Order)
                    .Include(o => o.Order.User)
                    .Include(o => o.StockProduct)
                    .Include(o => o.CustomerFile)
                    .FirstOrDefault(o => o.Order_Id == id) ?? new OrderDetails(); // Retrieve an order detail by its ID from the repository, including related entities (Order, User, StockProduct, and CustomerFile), or return a new OrderDetails object if not found
            }
        }

        public void CreateOrUpdateOrderDetails(OrderDetails orderDetails)
        {
            using (var repo = new Repository())
            {
                var existingOrderDetails = repo.OrderDetails.FirstOrDefault(od =>
                    od.StProduct_Id == orderDetails.StProduct_Id && od.Order_Id == orderDetails.Order_Id && od.CustomerFile_Id == orderDetails.CustomerFile_Id); // Check if the order detail already exists in the repository

                if (existingOrderDetails == null)
                {
                    repo.OrderDetails.Add(orderDetails); // Add the new order detail to the repository

                    var product = repo.StockProduct.FirstOrDefault(p => p.StProduct_Id == orderDetails.StProduct_Id); // Retrieve the associated StockProduct
                    if (product != null)
                    {
                        product.StProduct_UnitInStock -= orderDetails.Quantity; // Reduce the StockProduct's unit in stock by the ordered quantity

                        if (product.StProduct_UnitInStock < 0)
                        {
                            product.StProduct_UnitInStock = 0;

                            if (product.StProduct_UnitInStock == 0)
                            {
                                SendEmailToSupplier(product); // If the stock is depleted, send an email to the supplier
                            }
                        }
                    }
                }
                else
                {
                    repo.Attach(orderDetails);
                    var e = repo.ChangeTracker.Entries().FirstOrDefault(e => e.Entity == orderDetails);
                    e.State = EntityState.Modified; // Mark the existing order detail as modified in the repository
                }

                var sumproduct = repo.StockProduct.FirstOrDefault(p => p.StProduct_Id == orderDetails.StProduct_Id); // Retrieve the associated StockProduct
                double totalPrice = sumproduct?.StProduct_Price * orderDetails.Quantity ?? 0; // Calculate the total price based on the StockProduct's price and the ordered quantity

                orderDetails.TotalPrice = totalPrice; // Assign the total price to the TotalPrice property in OrderDetails

                repo.SaveChanges(); // Save the changes to the repository
            }
        }

        private void SendEmailToSupplier(StockProduct product)
        {
            var message = new MailMessage(); // Create a new email message
            message.From = new MailAddress("lieven.delameillieure@gmail.com");
            message.To.Add(new MailAddress("lieven.delameillieure@gmail.com"));
            message.Subject = "Stock Order";
            message.Body = $"Please place an order for product {product.StProduct_Id}. Current stock is empty.";

            // Your code to send the email message
            Console.WriteLine("Email sent (fake):");
            Console.WriteLine($"From: {message.From}");
            Console.WriteLine($"To: {string.Join(", ", message.To)}");
            Console.WriteLine($"Subject: {message.Subject}");
            Console.WriteLine($"Body: {message.Body}");

            product.StProduct_UnitInStock += 200; // Increase the StockProduct's unit in stock by 200 (assuming a stock replenishment)
        }

        public void DeleteOrderDetails(OrderDetails orderDetails)
        {
            using (var repo = new Repository())
            {
                repo.OrderDetails.Remove(orderDetails); // Remove the order detail from the repository
                repo.SaveChanges(); // Save the changes to the repository
            }
        }
    }
}
