﻿using Microsoft.EntityFrameworkCore;
using OrderSystemCompany.DA;
using OrderSystemCompany.Objects;

namespace OrderSystemCompany.Services
{
    public interface IMessagesServices
    {
        List<Messages> GetMessage(); // Retrieves a list of messages
        Messages GetMessagesById(int id); // Retrieves a message by its ID
        void CreateOrUpdateMessage(Messages messages); // Creates or updates a message
        bool DeleteMessage(int id); // Deletes a message by its ID
        string GetMessageFromMessagesController(); // Retrieves the description of the last message
    }

    public class MessagesServices : IMessagesServices
    {
        public List<Messages> GetMessage()
        {
            using (var repo = new Repository())
            {
                return repo.Messages.ToList(); // Retrieve all messages from the repository
            }
        }

        public Messages GetMessagesById(int id)
        {
            using (var repo = new Repository())
            {
                return repo.Messages.Include(u => u.User).FirstOrDefault(o => o.Message_Id == id) ?? new Messages(); // Retrieve a message by its ID from the repository, including the associated user, or return a new Messages object if not found
            }
        }

        public void CreateOrUpdateMessage(Messages messages)
        {
            using (var repo = new Repository())
            {
                if (messages.Message_Id == 0) // If the message ID is 0, it means it's a new message that needs to be created
                {
                    var newMessage = new Messages
                    {
                        Message_Description = messages.Message_Description,
                        User_Id = messages.User_Id,
                        Message_Date = messages.Message_Date
                    };

                    repo.Messages.Add(newMessage); // Add the new message to the repository
                }
                else // If the message ID is not 0, it means it's an existing message that needs to be updated
                {
                    repo.Attach(messages);
                    var e = repo.ChangeTracker.Entries().FirstOrDefault(e => e.Entity == messages);
                    e.State = EntityState.Modified; // Mark the message as modified in the repository
                }

                repo.SaveChanges(); // Save the changes to the repository
            }
        }

        public bool DeleteMessage(int id)
        {
            using (var repo = new Repository())
            {
                var message = repo.Messages.FirstOrDefault(c => c.Message_Id == id); // Find the message to delete by its ID
                if (message != null)
                {
                    repo.Messages.Remove(message); // Remove the message from the repository
                    repo.SaveChanges(); // Save the changes to the repository
                    return true;
                }

                return false; // Return false if the message with the specified ID was not found
            }
        }

        public string GetMessageFromMessagesController()
        {
            using (var repo = new Repository())
            {
                var message = repo.Messages.OrderByDescending(m => m.Message_Id).FirstOrDefault(); // Retrieve the last message from the repository
                if (message != null)
                {
                    return message.Message_Description; // Return the description of the last message
                }

                return ""; // Return an empty string if no messages are found
            }
        }
    }
}
