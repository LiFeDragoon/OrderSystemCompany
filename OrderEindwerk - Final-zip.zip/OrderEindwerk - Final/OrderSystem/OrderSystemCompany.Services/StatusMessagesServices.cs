﻿using Microsoft.EntityFrameworkCore;
using OrderSystemCompany.DA;
using OrderSystemCompany.Objects;

namespace OrderSystemCompany.Services
{
    public class StatusMessagesServices
    {
        private readonly Repository _context;

        public StatusMessagesServices(Repository context)
        {
            _context = context;
        }

        public List<StatusMessages> GetAllStatusMessages()
        {
            return _context.StatusMessages.ToList(); // Retrieve all status messages from the repository
        }

        public StatusMessages GetStatusMessageById(int id)
        {
            return _context.StatusMessages.FirstOrDefault(s => s.StatusMessage_Id == id); // Retrieve a status message by its ID from the repository
        }

        public void CreateOrUpdateStatusMessage(StatusMessages statusMessages)
        {
            using (var repo = new Repository())
            {
                if (statusMessages.StatusMessage_Id == 0)
                {
                    // Create a new Messages object with the provided description and other properties
                    var newMessage = new StatusMessages
                    {
                        StatusMessage_Description = statusMessages.StatusMessage_Description,
                        User_Id = statusMessages.User_Id,
                        StatusMessage_Date = statusMessages.StatusMessage_Date,
                        StatusMessage_Urgent = statusMessages.StatusMessage_Urgent,
                        StatusMessage_NotUrgent = statusMessages.StatusMessage_NotUrgent,
                        StatusMessage_Priority = statusMessages.StatusMessage_Priority
                    };

                    repo.StatusMessages.Add(newMessage); // Add the new status message to the repository
                }
                else
                {
                    repo.Attach(statusMessages);
                    var e = repo.ChangeTracker.Entries().FirstOrDefault(e => e.Entity == statusMessages);
                    e.State = EntityState.Modified; // Mark the existing status message as modified in the repository
                }

                repo.SaveChanges(); // Save the changes to the repository
            }
        }

        public void DeleteStatusMessage(int id)
        {
            var statusMessage = _context.StatusMessages.FirstOrDefault(s => s.StatusMessage_Id == id); // Find the status message by its ID
            if (statusMessage != null)
            {
                _context.StatusMessages.Remove(statusMessage); // Remove the status message from the repository
                _context.SaveChanges(); // Save the changes to the repository
            }
        }

        public string GetStatusMessageFromStatusMessagesController()
        {
            using (var repo = new Repository())
            {
                var stMessage = repo.StatusMessages.OrderByDescending(m => m.StatusMessage_Id).FirstOrDefault(); // Retrieve the latest status message from the repository
                if (stMessage != null)
                {
                    string priority = string.Empty;
                    if (stMessage.StatusMessage_NotUrgent)
                    {
                        priority = "Not Urgent";
                    }
                    else if (stMessage.StatusMessage_Urgent)
                    {
                        priority = "Urgent";
                    }
                    else if (stMessage.StatusMessage_Priority)
                    {
                        priority = "Priority";
                    }

                    return $"{stMessage.StatusMessage_Description} \n\n\n  Urgency: {priority}"; // Format and return the status message and its urgency
                }

                return ""; // Return an empty string if no status message is found
            }
        }
    }
}
