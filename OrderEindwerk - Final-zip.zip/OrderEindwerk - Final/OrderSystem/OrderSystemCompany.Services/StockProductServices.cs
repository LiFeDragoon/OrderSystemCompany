﻿using Microsoft.EntityFrameworkCore;
using OrderSystemCompany.DA;
using OrderSystemCompany.Objects;

namespace OrderSystemCompany.Services
{
    public interface IStockProductServices
    {
        List<StockProduct> GetStProduct();
        StockProduct GetStProductById(int id);
        bool DeleteStProduct(int id);
        void CreateOrUpdateStProduct(StockProduct stockProduct);
    }

    public class StockProductServices : IStockProductServices
    {
        // Retrieve all stock products including supplier and category information
        public List<StockProduct> GetStProduct()
        {
            using (var repo = new Repository())
            {
                return repo.StockProduct.Include(s => s.Supplier).Include(c => c.Category).ToList();
            }
        }

        // Retrieve a stock product by its ID including supplier and category information
        public StockProduct GetStProductById(int id)
        {
            using (var repo = new Repository())
            {
                return repo.StockProduct.Include(s => s.Supplier).Include(c => c.Category)
                    .FirstOrDefault(stockProduct => stockProduct.StProduct_Id == id) ?? new StockProduct();
            }
        }

        // Delete a stock product by its ID
        public bool DeleteStProduct(int id)
        {
            using (var repo = new Repository())
            {
                var product = repo.StockProduct.FirstOrDefault(c => c.StProduct_Id == id);
                if (product != null)
                {
                    repo.StockProduct.Remove(product);
                    repo.SaveChanges();
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        // Create or update a stock product
        public void CreateOrUpdateStProduct(StockProduct stockProduct)
        {
            using (var repo = new Repository())
            {
                if (stockProduct.StProduct_Id == 0)
                {
                    repo.StockProduct.Add(stockProduct); // Add a new stock product to the repository
                }
                else
                {
                    repo.Attach(stockProduct);
                    var e = repo.ChangeTracker.Entries().FirstOrDefault(e => e.Entity == stockProduct);
                    e.State = EntityState.Modified; // Mark the existing stock product as modified in the repository
                }
                repo.SaveChanges(); // Save the changes to the repository
            }
        }
    }
}
