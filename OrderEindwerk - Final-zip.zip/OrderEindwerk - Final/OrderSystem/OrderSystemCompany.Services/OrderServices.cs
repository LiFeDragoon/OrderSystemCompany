﻿using Microsoft.EntityFrameworkCore;
using OrderSystemCompany.DA;
using OrderSystemCompany.Objects;

namespace OrderSystemCompany.Services
{
    public interface IOrderServices
    {
        List<Order> GetOrder(); // Retrieves a list of orders
        Order GetOrderById(int id); // Retrieves an order by its ID
        bool DeleteOrder(int id); // Deletes an order
        void CreateOrUpdateOrder(Order order); // Creates or updates an order
    }

    public class OrderServices : IOrderServices
    {
        public List<Order> GetOrder()
        {
            using (var repo = new Repository())
            {
                return repo.Order
                    .Include(o => o.OrderDetails) // Include related OrderDetails entities
                    .ToList(); // Retrieve all orders from the repository
            }
        }

        public Order GetOrderById(int id)
        {
            using (var repo = new Repository())
            {
                return repo.Order
                    .Include(u => u.User) // Include related User entity
                    .Include(o => o.OrderDetails) // Include related OrderDetails entities
                    .ThenInclude(od => od.StockProduct) // Include related StockProduct entities within OrderDetails
                    .FirstOrDefault(o => o.Order_Id == id) ?? new Order(); // Retrieve an order by its ID from the repository, including related entities, or return a new Order object if not found
            }
        }

        public bool DeleteOrder(int id)
        {
            using (var repo = new Repository())
            {
                var order = repo.Order.FirstOrDefault(c => c.Order_Id == id); // Find the order by its ID
                if (order != null)
                {
                    var orderDetails = repo.OrderDetails.Where(od => od.Order_Id == id).ToList(); // Get the associated order details
                    foreach (var orderDetail in orderDetails)
                    {
                        var product = repo.StockProduct.FirstOrDefault(p => p.StProduct_Id == orderDetail.StProduct_Id); // Find the associated StockProduct
                        if (product != null)
                        {
                            product.StProduct_UnitInStock += orderDetail.Quantity; // Increase the StockProduct's unit in stock by the order detail's quantity
                        }
                    }

                    repo.Order.Remove(order); // Remove the order from the repository
                    repo.SaveChanges(); // Save the changes to the repository
                    return true;
                }

                return false; // Return false if the order doesn't exist
            }
        }

        public void CreateOrUpdateOrder(Order order)
        {
            using (var repo = new Repository())
            {
                if (order.Order_Id == 0)
                {
                    repo.Order.Add(order); // Add a new order to the repository
                }
                else
                {
                    repo.Attach(order);
                    var e = repo.ChangeTracker.Entries().FirstOrDefault(e => e.Entity == order);
                    e.State = EntityState.Modified; // Mark the existing order as modified in the repository
                }

                repo.SaveChanges(); // Save the changes to the repository
            }
        }
    }
}
