﻿using Microsoft.AspNetCore.Identity;

namespace OrderSystemCompany.Objects
{
    public class User : IdentityUser
    {
        // Personal data properties
        [PersonalData]
        public string? Address { get; set; } // Represents the address of the user

        [PersonalData]
        public string? City { get; set; } // Represents the city of the user

        [PersonalData]
        public string? Country { get; set; } // Represents the country of the user

        [PersonalData]
        public string? PostalCode { get; set; } // Represents the postal code of the user

        [PersonalData]
        public string? Phone { get; set; } // Represents the phone number of the user

        [PersonalData]
        public override string? Email { get; set; } // Represents the email address of the user

        [PersonalData]
        public string? Password { get; set; } // Represents the password of the user

        [PersonalData]
        public string? Name { get; set; } // Represents the name of the user
    }
}
