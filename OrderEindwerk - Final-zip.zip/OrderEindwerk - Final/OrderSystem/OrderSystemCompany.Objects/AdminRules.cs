﻿// Namespace where the AdminRoles enum is defined
namespace OrderSystemCompany.Objects
{
    // Enum defining the roles for the administration system
    public enum AdminRoles
    {
        User,  // Represents the role of a regular user
        Admin // Represents the role of an administrator
    }
}
