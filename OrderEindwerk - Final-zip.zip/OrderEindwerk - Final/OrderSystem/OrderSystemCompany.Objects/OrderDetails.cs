﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

// Namespace where the OrderDetails class is defined
namespace OrderSystemCompany.Objects
{
    [Table("OrderDetails")] // Specifies the table name in the database
    [PrimaryKey(nameof(StProduct_Id), nameof(Order_Id))] // Specifies the primary key for the table
    public class OrderDetails
    {
        [Column("StProduct_Id")] // Specifies the column name in the database
        [ForeignKey("StockProduct")] // Specifies the relationship to the "StockProduct" entity
        public int? StProduct_Id { get; set; }
        public StockProduct? StockProduct { get; set; } // Navigation property representing the associated stock product entity

        [Column("Order_Id")] // Specifies the column name in the database
        [ForeignKey("Order")] // Specifies the relationship to the "Order" entity
        public int? Order_Id { get; set; }
        [JsonIgnore] // Excludes this property from serialization
        public Order? Order { get; set; } // Navigation property representing the associated order entity

        public double? Quantity { get; set; } // Represents the quantity of the ordered product
        public double? TotalPrice { get; set; } // Represents the total price of the ordered product
        [JsonIgnore]
        [ForeignKey("CustomerFile")] // Specifies the relationship to the "CustomerFile" entity   
        public int? CustomerFile_Id { get; set; }
        [JsonIgnore]
        public CustomerFile? CustomerFile { get; set; } // Navigation property representing the associated customer file entity
    }
}
