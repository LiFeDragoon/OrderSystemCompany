﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OrderSystemCompany.Objects
{
    [Table("TblSupplier")] // Specifies the table name in the database
    public class Supplier
    {
        [Key] // Indicates that this property is the primary key
        public int Supplier_Id { get; set; } // Represents the supplier identifier

        public string? Supplier_Name { get; set; } // Represents the name of the supplier
        public string? Supplier_Address { get; set; } // Represents the address of the supplier
        public string? Supplier_City { get; set; } // Represents the city of the supplier
        public string? Supplier_Country { get; set; } // Represents the country of the supplier
        public string? Supplier_PostalCode { get; set; } // Represents the postal code of the supplier
        public string? Supplier_Phone { get; set; } // Represents the phone number of the supplier
        public string? Supplier_Email { get; set; } // Represents the email address of the supplier
    }
}
