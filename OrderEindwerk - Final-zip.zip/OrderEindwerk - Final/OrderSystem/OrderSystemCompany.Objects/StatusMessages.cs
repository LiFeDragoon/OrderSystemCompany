﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace OrderSystemCompany.Objects
{
    [Table("TblStatusMessages")] // Specifies the table name in the database
    public class StatusMessages
    {
        [Key] // Indicates that this property is the primary key
        [JsonIgnore] // Excludes this property from serialization
        public int StatusMessage_Id { get; set; } // Represents the status message identifier

        public string? StatusMessage_Description { get; set; } // Represents the description of the status message

        [JsonIgnore] // Excludes this property from serialization
        public DateTime? StatusMessage_Date { get; set; } // Represents the date of the status message

        public bool StatusMessage_Urgent { get; set; } // Represents whether the status message is marked as urgent
        public bool StatusMessage_NotUrgent { get; set; } // Represents whether the status message is marked as not urgent
        public bool StatusMessage_Priority { get; set; } // Represents the priority of the status message

        // Use foreign key to bind to a user
        [JsonIgnore] // Excludes this property from serialization
        [ForeignKey("User")] // Specifies the relationship to the "User" entity
        public string? User_Id { get; set; } // Represents the foreign key for the associated user

        [JsonIgnore] // Excludes this property from serialization
        public User? User { get; set; } // Navigation property representing the associated user entity
    }
}
