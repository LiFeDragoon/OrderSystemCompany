﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

// Namespace where the Order class is defined
namespace OrderSystemCompany.Objects
{
    // Table attribute specifying the table name in the database
    [Table("TblOrder")]
    public class Order
    {
        // Key attribute indicating the primary key property of the entity
        [Key]
        public int Order_Id { get; set; }

        // Property representing the order date
        public DateTime Order_Date { get; set; }

        // Property representing the order ship date
        public DateTime Order_ShipDate { get; set; }

        // Property representing whether the order has been shipped
        public bool Order_Shipped { get; set; }

        // Property representing whether the payment for the order has been received
        public bool Order_PaymentReceived { get; set; }

        // Property representing the foreign key to bind to a user
        [JsonIgnore]
        [ForeignKey("User")]
        public string? User_Id { get; set; }

        // Navigation property representing the associated user entity
        [JsonIgnore]
        public User? User { get; set; }

        // Collection navigation property representing the associated order details entities
        public ICollection<OrderDetails>? OrderDetails { get; set; }
    }
}
