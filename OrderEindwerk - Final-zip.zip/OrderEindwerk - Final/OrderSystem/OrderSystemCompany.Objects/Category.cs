﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Namespace where the Category class is defined
namespace OrderSystemCompany.Objects
{
    // Table attribute specifying the table name in the database
    [Table("TblCategory")]
    public class Category
    {
        // Key attribute indicating the primary key property of the entity
        [Key]

        public int Cat_Id { get; set; }

        // Property representing the category name
        public string? Cat_Name { get; set; }
    }
}
