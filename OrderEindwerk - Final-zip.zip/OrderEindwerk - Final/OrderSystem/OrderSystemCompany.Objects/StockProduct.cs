﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace OrderSystemCompany.Objects
{
    [Table("TblStockProduct")] // Specifies the table name in the database
    public class StockProduct
    {
        [Key] // Indicates that this property is the primary key
        public int StProduct_Id { get; set; } // Represents the stock product identifier

        public string? StProduct_Name { get; set; } // Represents the name of the stock product
        public string? StProduct_Description { get; set; } // Represents the description of the stock product
        public double? StProduct_Price { get; set; } // Represents the price of the stock product
        public double? StProduct_UnitInStock { get; set; } // Represents the available units of the stock product

        [ForeignKey("Supplier")] // Specifies the relationship to the "Supplier" entity
        public int Supplier_Id { get; set; } // Represents the foreign key for the associated supplier

        [JsonIgnore] // Excludes this property from serialization
        public Supplier? Supplier { get; set; } // Navigation property representing the associated supplier entity

        [ForeignKey("Category")] // Specifies the relationship to the "Category" entity
        public int Cat_Id { get; set; } // Represents the foreign key for the associated category

        public Category? Category { get; set; } // Navigation property representing the associated category entity

        [JsonIgnore] // Excludes this property from serialization
        public ICollection<OrderDetails>? OrderDetails { get; set; } // Navigation property representing the collection of associated order details
    }
}
