﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

// Namespace where the Messages class is defined
namespace OrderSystemCompany.Objects
{
    // Table attribute specifying the table name in the database
    [Table("TblMessages")]
    public class Messages
    {
        // Key attribute indicating the primary key property of the entity
        [Key]
        [JsonIgnore]
        public int Message_Id { get; set; }

        // Property representing the message description
        public string? Message_Description { get; set; }

        // Property representing the message date
        [JsonIgnore]
        public DateTime? Message_Date { get; set; }

        // Property representing the foreign key to bind to a user
        [JsonIgnore]
        [ForeignKey("User")]
        public string? User_Id { get; set; }

        // Navigation property representing the associated user entity
        [JsonIgnore]
        public User? User { get; set; }
    }
}
