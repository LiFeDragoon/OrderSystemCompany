﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Namespace where the CustomerFile class is defined
namespace OrderSystemCompany.Objects
{
    // Table attribute specifying the table name in the database
    [Table("TblCustomerFile")]
    public class CustomerFile
    {
        // Key attribute indicating the primary key property of the entity
        [Key]
        public int CustomerFile_Id { get; set; }

        // Property representing the customer file name
        public string? CustomerFile_Name { get; set; }

        // Property representing the customer file address
        public string? CustomerFile_Address { get; set; }

        // Property representing the customer file city
        public string? CustomerFile_City { get; set; }

        // Property representing the customer file country
        public string? CustomerFile_Country { get; set; }

        // Property representing the customer file postal code
        public string? CustomerFile_PostalCode { get; set; }

        // Property representing the customer file phone number
        public string? CustomerFile_Phone { get; set; }

        // Property representing the customer file email
        public string? CustomerFile_Email { get; set; }
    }
}
